import { useEffect, useMemo, useState } from 'react'
import {
  loadAllHistory,
  loadHistoricalRun,
  loadHistory,
  loadLatestForStrategy,
  loadStrategy,
  loadStrategyConfig,
  saveStrategyConfig,
} from './api'

const riskLabel = { low: '低', medium: '中等', high: '较高' }
const tagStatusLabel = { partial: '部分符合', missing_data: '待验证', excluded: '非主策略', matched: '主策略命中' }

const STRATEGY_TABS = [
  { id: 'fishing-reversal', label: 'V1 尾盘恐慌止跌', priority: 'V1' },
  { id: 'p1-sector-resonance', label: 'P1 板块共振', priority: 'P1' },
  { id: 'p2-trend-pullback', label: 'P2 趋势缩量回踩', priority: 'P2' },
  { id: 'p3-platform-breakout', label: 'P3 平台放量突破', priority: 'P3' },
  { id: 'p4-leader-reconvergence', label: 'P4 龙头分歧转一致', priority: 'P4' },
]

const STATUS_FILTERS = [
  { id: 'all', label: '全部' },
  { id: 'matched', label: '命中' },
  { id: 'partial', label: '部分符合' },
  { id: 'missing_data', label: '待验证' },
  { id: 'excluded', label: '非主策略' },
]

const HISTORY_STATUS_LABEL = {
  tradable: '可执行',
  outside_tail_window: '非可执行时段',
}

function PrimaryTag({ tags = [] }) {
  const tag = tags.find((item) => item.key === 'sector_resonance_pullback')
  if (!tag) return <span className="tag-chip missing_data">新快照后生成</span>
  return <span className={`tag-chip ${tag.status}`}>{tagStatusLabel[tag.status]}</span>
}

function PriorityTags({ tags = [] }) {
  if (!tags.length) return <p className="muted tag-empty">这是旧快照；重新运行后会生成优先级标签。</p>
  return <div className="priority-tags">{tags.map((tag) => <div className="priority-tag" key={tag.key}>
    <div><strong>{tag.label}</strong><span className={`tag-chip ${tag.status}`}>{tagStatusLabel[tag.status] || tag.status}</span></div>
    <ul>{tag.evidence.map((item) => <li key={item}>{item}</li>)}</ul>
  </div>)}</div>
}

function ConfigDrawer({ strategy, onClose }) {
  const [config, setConfig] = useState(strategy?.config || {})
  const [pending, setPending] = useState({})
  const [savedAt, setSavedAt] = useState(null)
  const [saving, setSaving] = useState(false)

  if (!strategy) return null

  const apply = async () => {
    setSaving(true)
    try {
      const result = await saveStrategyConfig(strategy.id, pending)
      setConfig(result.config)
      setPending({})
      setSavedAt(new Date().toLocaleTimeString('zh-CN'))
    } catch (error) {
      alert(error.message)
    } finally {
      setSaving(false)
    }
  }

  return <div className="config-drawer">
    <div className="drawer-head">
      <h3>{strategy.name} · 调参</h3>
      <button onClick={onClose}>×</button>
    </div>
    <p className="muted">覆盖字段会立即生效，下次跑策略按新阈值判定。非法字段会被忽略。</p>
    <div className="config-grid">
      {Object.entries(config).map(([key, value]) => (
        <label key={key}>
          <span>{key}</span>
          <input
            value={pending[key] ?? value}
            type={typeof value === 'number' ? 'number' : 'text'}
            step="any"
            onChange={(e) => {
              const raw = e.target.value
              const next = typeof value === 'number' ? Number(raw) : raw
              setPending((prev) => ({ ...prev, [key]: Number.isNaN(next) ? raw : next }))
            }}
          />
        </label>
      ))}
    </div>
    <div className="drawer-foot">
      {savedAt && <span className="muted">已保存 {savedAt}</span>}
      <button onClick={apply} disabled={saving || Object.keys(pending).length === 0}>
        {saving ? '保存中…' : '应用覆盖'}
      </button>
    </div>
  </div>
}

function formatTime(value) {
  return value ? new Date(value).toLocaleString('zh-CN', { hour12: false }) : '尚未运行'
}

function historyDate(value) {
  return new Intl.DateTimeFormat('zh-CN', { month: 'long', day: 'numeric', weekday: 'short' }).format(new Date(value))
}

function historyClock(value) {
  return new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(value))
}

function HistoryPanel({ activeRunId, onOpenRun }) {
  const [filters, setFilters] = useState({ strategy: 'all', dateFrom: '', dateTo: '' })
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const controller = new AbortController()
    const params = {}
    if (filters.dateFrom) params.date_from = filters.dateFrom
    if (filters.dateTo) params.date_to = filters.dateTo
    const fetcher = filters.strategy === 'all'
      ? loadAllHistory(params, { signal: controller.signal })
      : loadHistory(filters.strategy, params, { signal: controller.signal })

    setLoading(true)
    setError(null)
    fetcher
      .then((data) => setRows(data.runs || []))
      .catch((requestError) => {
        if (requestError.name !== 'AbortError') setError(requestError.message)
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false)
      })
    return () => controller.abort()
  }, [filters])

  const groups = useMemo(() => rows.reduce((result, row) => {
    const key = new Date(row.observed_at).toISOString().slice(0, 10)
    const previous = result[result.length - 1]
    if (previous?.key === key) previous.rows.push(row)
    else result.push({ key, label: historyDate(row.observed_at), rows: [row] })
    return result
  }, []), [rows])

  return <section className="history-panel" aria-label="历史推荐快照">
    <div className="history-head">
      <div>
        <span className="eyebrow">策略归档</span>
        <h2>历史回看</h2>
        <p>每个交易日尾盘的正式自动采集，都可以回到当时的候选、评分和数据来源。</p>
      </div>
      <div className="history-filters">
        <select aria-label="按策略筛选历史记录" value={filters.strategy}
          onChange={(event) => setFilters((current) => ({ ...current, strategy: event.target.value }))}>
          <option value="all">全部策略</option>
          {STRATEGY_TABS.map((tab) => <option key={tab.id} value={tab.id}>{tab.label}</option>)}
        </select>
        <input aria-label="历史起始日期" type="date" value={filters.dateFrom}
          onChange={(event) => setFilters((current) => ({ ...current, dateFrom: event.target.value }))} />
        <span>至</span>
        <input aria-label="历史截止日期" type="date" value={filters.dateTo}
          onChange={(event) => setFilters((current) => ({ ...current, dateTo: event.target.value }))} />
        <button type="button" className="history-reset" disabled={loading}
          onClick={() => setFilters({ strategy: 'all', dateFrom: '', dateTo: '' })}>重置</button>
      </div>
    </div>

    <div className="history-summary">
      <span>{loading ? '正在更新归档…' : `已找到 ${rows.length} 次正式归档`}</span>
      <span>仅展示实时数据</span>
    </div>
    {error ? <p className="history-empty">{error}</p>
      : !loading && groups.length === 0 ? <p className="history-empty">尚无符合条件的实时归档。尾盘运行策略后会自动出现在这里。</p>
        : <div className="history-timeline">
          {groups.map((group) => <section className="history-day" key={group.key}>
            <h3>{group.label}</h3>
            <div className="history-list">
              {group.rows.map((row) => {
                const tab = STRATEGY_TABS.find((item) => item.id === row.strategy_id)
                const isActive = activeRunId === row.run_id
                return <button type="button" key={row.run_id}
                  className={`history-item ${isActive ? 'active' : ''}`}
                  onClick={() => onOpenRun(row)} aria-pressed={isActive}>
                  <time dateTime={row.observed_at}><strong>{historyClock(row.observed_at)}</strong><small>{tab?.priority ?? '策略'}</small></time>
                  <span className="history-strategy"><strong>{tab?.label ?? row.strategy_id}</strong><small>{row.data_source} · {HISTORY_STATUS_LABEL[row.execution_status] || row.execution_status}</small></span>
                  <span className="history-signal-count"><strong>{row.signal_count}</strong><small>候选</small></span>
                  <span className="history-arrow" aria-hidden="true">→</span>
                </button>
              })}
            </div>
          </section>)}
        </div>}
  </section>
}

export default function App() {
  const [definitions, setDefinitions] = useState([])
  const [activeStrategy, setActiveStrategy] = useState('fishing-reversal')
  const [runs, setRuns] = useState({})
  const [selected, setSelected] = useState(null)
  const [status, setStatus] = useState('正在加载自动归档…')
  const [statusFilter, setStatusFilter] = useState('all')
  const [showConfig, setShowConfig] = useState(null)

  const [viewingHistorical, setViewingHistorical] = useState(null)

  useEffect(() => {
    Promise.all([
      loadStrategy(),
      Promise.all(STRATEGY_TABS.map((tab) => loadLatestForStrategy(tab.id).catch(() => null))),
    ])
      .then(([catalog, latestPerStrategy]) => {
        setDefinitions(catalog.strategies)
        const runMap = {}
        latestPerStrategy.forEach((run, index) => {
          const tab = STRATEGY_TABS[index]
          if (run) runMap[tab.id] = run
        })
        setRuns(runMap)
        setSelected(runMap[activeStrategy]?.signals?.[0] ?? null)
        setStatus('已读取最近一次自动归档')
      })
      .catch((error) => setStatus(error.message))
  }, [])

  const activeRun = viewingHistorical?.run || runs[activeStrategy] || null
  const run = activeRun
  const definition = definitions.find((d) => d.id === activeStrategy) || null

  const filteredSignals = useMemo(() => {
    const list = run?.signals || []
    if (statusFilter === 'all') return list
    return list.filter((signal) => (signal.priority_tags || []).some((t) => t.status === statusFilter))
  }, [run, statusFilter])

  const stats = useMemo(() => ({
    candidates: run?.signals?.length ?? 0,
    universe: run?.universe_size ?? 0,
    observed: formatTime(run?.observed_at),
  }), [run])

  async function openConfig() {
    try {
      const result = await loadStrategyConfig(activeStrategy)
      const def = definitions.find((d) => d.id === activeStrategy)
      setShowConfig({ id: activeStrategy, name: def?.name || activeStrategy, config: result.config })
    } catch (error) {
      setStatus(error.message)
    }
  }

  async function openHistoricalRun(row) {
    try {
      const full = await loadHistoricalRun(row.strategy_id, row.run_id)
      setActiveStrategy(row.strategy_id)
      setSelected(full.signals?.[0] ?? null)
      setViewingHistorical({ run: full, row })
      setStatusFilter('all')
      setStatus(`已加载 ${row.strategy_id} 在 ${formatTime(full.observed_at)} 的历史快照。`)
    } catch (error) {
      setStatus(error.message)
    }
  }

  function backToLatest() {
    const latest = runs[activeStrategy]
    setViewingHistorical(null)
    setSelected(latest?.signals?.[0] ?? null)
    setStatus('已回到最新一次实时快照。')
  }

  function pickStrategy(id) {
    setActiveStrategy(id)
    setViewingHistorical(null)
    setSelected(runs[id]?.signals?.[0] ?? null)
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand">尾盘策略实验室</div>
      <nav>
        {STRATEGY_TABS.map((tab) => (
          <a key={tab.id} href={`#${tab.id}`} className={activeStrategy === tab.id ? 'active' : ''}
             onClick={(e) => { e.preventDefault(); pickStrategy(tab.id) }}>
            <span className="tab-priority">{tab.priority}</span>{tab.label}
          </a>
        ))}
        <a href="#backtest">T+1 回测</a>
      </nav>
      <div className="sidebar-note">仅研究，不构成投资建议</div>
    </aside>
    <main className="workspace">
      {viewingHistorical && <div className="historical-banner" role="status">
        <span>
          正在查看历史快照 ·
          <strong>{viewingHistorical.row.strategy_id}</strong>
          · {formatTime(viewingHistorical.run.observed_at)} ·
          <em>{viewingHistorical.row.signal_count} 候选 · {viewingHistorical.row.universe_size} 扫描</em>
        </span>
        <button onClick={backToLatest}>回到最新</button>
      </div>}
      <header className="topbar">
        <span>研究快照</span>
        <strong>{stats.observed}</strong>
        <span className="dot" />
        <span>{run ? (run.execution_status === 'tradable' ? '自动归档 · 可执行时段' : '自动归档 · 非可执行时段') : '等待下次自动归档'}</span>
        <span className="source-tag">{run?.data_source ?? '等待数据源'}</span>
      </header>
      <section className="headline">
        <div>
          <h1>{definition?.name ?? '尾盘恐慌止跌'} <span>· {definition?.version ?? 'V1'}</span></h1>
          <p>{definition?.summary ?? '加载中'}</p>
        </div>
        <div className="actions">
          <p className="automation-note"><strong>自动采集</strong><span>交易日 14:50 生成正式快照</span></p>
          <button className="ghost" onClick={openConfig}>参数调优</button>
        </div>
      </section>
      <p className="risk-copy">风险提示：策略只生成可研究的候选，不能保证次日盈利；隔夜跳空可能使风险线失效。</p>
      <p className="status-line" role="status">{status}</p>

      <section className="summary-strip">
        <div><span>候选信号</span><strong>{stats.candidates}</strong></div>
        <div><span>扫描范围</span><strong>{stats.universe || '—'}</strong></div>
        <div><span>执行时段</span><strong>{definition?.execution_window ?? '14:30–15:00'}</strong></div>
      </section>

      <HistoryPanel
        activeRunId={viewingHistorical?.row.run_id}
        onOpenRun={openHistoricalRun}
      />

      <section className="content-grid">
        <div className="signal-area">
          <div className="section-heading">
            <h2>{definition?.name ?? '候选池'}</h2>
            <div className="status-filters">
              {STATUS_FILTERS.map((f) => (
                <button key={f.id} className={statusFilter === f.id ? 'active' : ''}
                  onClick={() => setStatusFilter(f.id)}>
                  {f.label}
                </button>
              ))}
            </div>
          </div>
          <div className="table-wrap"><table>
            <thead><tr><th>排名</th><th>股票</th><th>评分</th><th>优先级标签</th><th>关键因子</th><th>风险</th></tr></thead>
            <tbody>
              {filteredSignals.length ? filteredSignals.map((signal, index) => <tr key={signal.code} onClick={() => setSelected(signal)} className={selected?.code === signal.code ? 'selected-row' : ''}>
                <td>{index + 1}</td>
                <td><strong>{signal.code} {signal.name}</strong><small>{signal.reason}</small></td>
                <td className="score">{signal.score}</td>
                <td><PrimaryTag tags={signal.priority_tags} /></td>
                <td>{(signal.factors || []).slice(0, 2).map((f) => `${f.label} ${f.value}`).join(' / ')}</td>
                <td className={`risk ${signal.risk_level}`}>{riskLabel[signal.risk_level]}</td>
              </tr>) : <tr><td colSpan="6" className="empty">无符合当前筛选的候选。可切到“全部”看完整池，或调低阈值。</td></tr>}
            </tbody>
          </table></div>
        </div>
        <aside className="inspector">
          <h2>信号详情</h2>
          {selected ? <>
            <h3>{selected.code} {selected.name}</h3>
            <p className="muted">评分 {selected.score} · 风险 {riskLabel[selected.risk_level]}</p>
            <div className="factor-list">
              {(selected.factors || []).map((factor) => <div key={factor.key}>
                <span>{factor.label}<small>{factor.description}</small></span>
                <strong>{factor.value}<em> +{factor.score}</em></strong>
              </div>)}
            </div>
            <h4 className="tag-heading">优先级策略适配</h4>
            <PriorityTags tags={selected.priority_tags} />
            <p className="rule-note">{definition?.risk_rule}</p>
          </> : <p className="muted">选择一条候选信号查看因子拆解。</p>}
        </aside>
      </section>

      <section id="backtest" className="backtest-band">
        <div className="section-heading">
          <div><h2>T+1 是否可盈利离场</h2><span>仅以已归档的实时尾盘信号和次日实际分钟路径统计</span></div>
        </div>
        <p className="muted">真实回测需要积累带时间戳的尾盘快照与次日分钟路径；不再展示内置样例数据。</p>
      </section>
    </main>
    {showConfig && <div className="drawer-overlay" onClick={() => setShowConfig(null)}>
      <div onClick={(e) => e.stopPropagation()}>
        <ConfigDrawer strategy={showConfig} onClose={() => setShowConfig(null)} />
      </div>
    </div>}
  </div>
}
