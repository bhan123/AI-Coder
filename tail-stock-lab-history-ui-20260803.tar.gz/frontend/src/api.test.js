import assert from 'node:assert/strict'
import test from 'node:test'

import { loadAllHistory, loadHistoricalRun, loadHistory, runStrategy } from './api.js'

test('runStrategy requests a live snapshot for the currently selected strategy', async () => {
  let requestedPath = null
  globalThis.fetch = async (path) => {
    requestedPath = path
    return { ok: true, json: async () => ({}) }
  }

  await runStrategy('p1-sector-resonance')

  assert.equal(
    requestedPath,
    '/api/strategies/p1-sector-resonance/run?mode=live',
  )
})

test('loadHistory omits empty params and preserves filled ones', async () => {
  let requestedPath = null
  globalThis.fetch = async (path) => {
    requestedPath = path
    return { ok: true, json: async () => ({ runs: [] }) }
  }

  await loadHistory('fishing-reversal', { date_from: '2026-08-01', date_to: '' })
  assert.equal(requestedPath, '/api/strategies/fishing-reversal/history?date_from=2026-08-01')

  await loadAllHistory({ date_from: '2026-08-01', date_to: '2026-08-03' })
  assert.equal(
    requestedPath,
    '/api/strategies/history?date_from=2026-08-01&date_to=2026-08-03',
  )

  await loadHistoricalRun('fishing-reversal', 'run-abc')
  assert.equal(requestedPath, '/api/strategies/fishing-reversal/run/run-abc')
})
