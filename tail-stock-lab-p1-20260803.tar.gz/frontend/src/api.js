export async function request(path, options) {
  const response = await fetch(path, options)
  if (!response.ok) {
    const payload = await response.json().catch(() => ({}))
    throw new Error(payload.detail || '服务暂不可用')
  }
  return response.json()
}

export const loadStrategy = () => request('/api/strategies')
export const loadLatest = () => request('/api/strategies/fishing-reversal/latest')
export const runStrategy = (sid, mode) => request(`/api/strategies/${sid}/run?mode=${mode}`, { method: 'POST' })
export const sampleBacktest = () => request('/api/strategies/fishing-reversal/backtest/sample', { method: 'POST' })
export const runAllStrategies = (mode) => request(`/api/strategies/run-all?mode=${mode}`, { method: 'POST' })
export const loadLatestForStrategy = (sid) => request(`/api/strategies/${sid}/latest`)
export const loadStrategyConfig = (sid) => request(`/api/strategies/${sid}/config`)
export const saveStrategyConfig = (sid, overrides) => request(`/api/strategies/${sid}/config`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ overrides }),
})
export const previewStrategy = (sid, mode = 'sample') => request(`/api/strategies/${sid}/preview?mode=${mode}`, { method: 'POST' })
