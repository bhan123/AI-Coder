import assert from 'node:assert/strict'
import test from 'node:test'

import { runStrategy } from './api.js'

test('runStrategy addresses the currently selected strategy', async () => {
  let requestedPath = null
  globalThis.fetch = async (path) => {
    requestedPath = path
    return { ok: true, json: async () => ({}) }
  }

  await runStrategy('p1-sector-resonance', 'sample')

  assert.equal(
    requestedPath,
    '/api/strategies/p1-sector-resonance/run?mode=sample',
  )
})
