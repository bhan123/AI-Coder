"""P1–P4 策略的真实数据测试。

每个策略都至少覆盖三条路径：
  - 完整数据 → 标签升级为 matched 或给出真实因子；
  - 数据缺失 → 标记 missing_data，但绝不假装有数据；
  - 数据形态不达标 → partial，给出真实证据。
"""

from __future__ import annotations

from datetime import date, datetime

import pytest

from app.data_provider import (
    ContextAssembler,
    SampleHistoryProvider,
    SampleIntradayProvider,
    SampleProvider,
    SampleSectorProvider,
)
from app.models import MarketSnapshot
from app.strategies import (
    FishingV1Strategy,
    LeaderReconvergenceStrategy,
    PlatformBreakoutStrategy,
    SectorResonancePullbackStrategy,
    TrendPullbackStrategy,
)


def _assemble(captured_at: datetime) -> dict[str, object]:
    snapshots = SampleProvider().fetch(captured_at)
    assembler = ContextAssembler(
        SampleHistoryProvider(),
        SampleIntradayProvider(),
        SampleSectorProvider(),
    )
    contexts = assembler.assemble(snapshots, captured_at)
    return contexts


@pytest.fixture
def contexts() -> dict[str, object]:
    return _assemble(datetime(2026, 7, 31, 14, 50))


# ---------------------------------------------------------------------------
# P1
# ---------------------------------------------------------------------------

def test_p1_real_intraday_data_drives_sector_resonance_label(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    positive_peer = context.sector_peers[-1]
    context.sector_peers.extend([
        positive_peer.model_copy(update={"code": "605001", "name": "联动样例一"}),
        positive_peer.model_copy(update={"code": "605002", "name": "联动样例二"}),
    ])
    context.snapshot = context.snapshot.model_copy(update={"pct_change": 3.0})
    context.intraday_bars[-1] = context.intraday_bars[-1].model_copy(
        update={"price": max(bar.price for bar in context.intraday_bars)}
    )
    sector_signal = strategy.evaluate_context(context)
    assert sector_signal.eligible is True
    status = sector_signal.priority_tags[0].status
    assert status == "matched"
    assert any("板块" in item for item in sector_signal.priority_tags[0].evidence)
    factor_keys = {factor.key for factor in sector_signal.factors}
    assert {"sector_strength", "vwap_hold_ratio", "volume_shrink"}.issubset(factor_keys)


def test_p1_without_sector_data_honest_missing_label(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    from app.models import MarketContext
    bare_snapshot = MarketSnapshot(
        code="999999",
        name="无板块样例",
        price=10.0,
        pct_change=-3.0,
        day_low=9.8,
        turnover_rate=2.0,
        volume_ratio=1.0,
        market_pct_change=-1.0,
        captured_at=datetime(2026, 7, 31, 14, 50),
    )
    signal = strategy.evaluate_context(MarketContext(snapshot=bare_snapshot))
    assert signal.eligible is False
    assert signal.priority_tags[0].status == "missing_data"
    assert signal.priority_tags[0].evidence


def test_p1_rejects_isolated_stock_even_when_it_ranks_first_within_sector(contexts) -> None:
    """个股排名不能被当成板块共振家数；单股独舞必须被排除。"""
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    context.sector_peers = []
    context.sector_rank = 1
    context.sector_total = 50

    signal = strategy.evaluate_context(context)

    resonance = next(factor for factor in signal.factors if factor.key == "sector_resonance")
    assert resonance.value == 0
    assert signal.eligible is False
    assert "同步上涨仅 0 只" in signal.reason


def test_p1_default_requires_at_least_three_rising_sector_members(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    positive_peer = context.sector_peers[-1]
    context.sector_peers = [
        positive_peer,
        positive_peer.model_copy(update={"code": "605001", "name": "板块联动样例"}),
    ]

    signal = strategy.evaluate_context(context)

    assert signal.eligible is False
    assert "同步上涨仅 2 只" in signal.reason


def test_p1_resonance_score_uses_member_count_not_number_of_sectors(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    context.sector_peers = [
        peer for peer in context.sector_peers if peer.pct_change > 0
    ][:3]
    context.snapshot = context.snapshot.model_copy(update={"pct_change": 3.0})
    context.sector_rank = 1
    context.sector_total = 100

    signal = strategy.evaluate_context(context)

    resonance = next(factor for factor in signal.factors if factor.key == "sector_resonance")
    assert resonance.value == 3
    assert resonance.score > 0


def test_context_uses_sector_strength_rank_not_stock_rank_within_sector(contexts) -> None:
    context = contexts["002833"]

    assert context.sector.code == "BK0001"
    assert context.sector_rank == 1
    assert context.sector_total == 3


def test_v1_priority_evidence_keeps_sector_member_denominator(contexts) -> None:
    signal = FishingV1Strategy().evaluate_context(contexts["002833"])
    p1_tag = next(
        tag for tag in signal.priority_tags if tag.key == "sector_resonance_pullback"
    )

    assert "同板块同步上涨 4/6" in p1_tag.evidence


def test_p1_rejects_sector_outside_front_thirty_percent(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    positive_peer = context.sector_peers[-1]
    context.sector_peers.extend([
        positive_peer.model_copy(update={"code": "605001"}),
        positive_peer.model_copy(update={"code": "605002"}),
    ])
    context.sector_rank = 2
    context.sector_total = 3

    signal = strategy.evaluate_context(context)

    assert signal.eligible is False
    assert "板块排名 2/3" in signal.reason


def test_p1_requires_stock_to_have_proven_intraday_strength(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    positive_peer = context.sector_peers[-1]
    context.sector_peers.extend([
        positive_peer.model_copy(update={"code": "605001"}),
        positive_peer.model_copy(update={"code": "605002"}),
    ])

    signal = strategy.evaluate_context(context)

    assert signal.snapshot.pct_change < 0
    assert signal.eligible is False
    assert "个股涨幅" in signal.reason


def test_p1_requires_stock_to_outperform_its_sector_average(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    peer = next(item for item in context.sector_peers if item.pct_change > 0)
    context.sector_peers = [
        peer.model_copy(update={"code": "605001", "pct_change": 5.0}),
        peer.model_copy(update={"code": "605002", "pct_change": 4.0}),
        peer.model_copy(update={"code": "605003", "pct_change": 3.0}),
    ]
    context.snapshot = context.snapshot.model_copy(update={"pct_change": 1.0})
    context.intraday_bars[-1] = context.intraday_bars[-1].model_copy(
        update={"price": max(bar.price for bar in context.intraday_bars)}
    )

    signal = strategy.evaluate_context(context)

    assert signal.eligible is False
    assert "弱于板块平均" in signal.reason


def test_p1_rejects_pullback_that_breaks_intraday_vwap(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    positive_peer = context.sector_peers[-1]
    context.sector_peers.extend([
        positive_peer.model_copy(update={"code": "605001"}),
        positive_peer.model_copy(update={"code": "605002"}),
    ])
    context.snapshot = context.snapshot.model_copy(update={"pct_change": 3.0})
    context.intraday_bars = [
        bar.model_copy(update={"price": bar.avg_price * 0.99})
        if 190 <= bar.minutes_after_open <= 200 else bar
        for bar in context.intraday_bars
    ]

    signal = strategy.evaluate_context(context)

    assert signal.eligible is False
    assert "跌破均价线" in signal.reason


def test_p1_requires_restrengthening_between_1435_and_1455(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    positive_peer = context.sector_peers[-1]
    context.sector_peers.extend([
        positive_peer.model_copy(update={"code": "605001"}),
        positive_peer.model_copy(update={"code": "605002"}),
    ])
    context.snapshot = context.snapshot.model_copy(update={"pct_change": 3.0})
    context.intraday_bars = [
        bar.model_copy(update={"price": 16.2, "avg_price": 16.0})
        if bar.minutes_after_open >= 180 else bar
        for bar in context.intraday_bars
    ]

    signal = strategy.evaluate_context(context)

    assert signal.eligible is False
    assert "14:35–14:55 未重新转强" in signal.reason


def test_p1_measures_volume_across_the_whole_post_1400_pullback(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    positive_peer = context.sector_peers[-1]
    context.sector_peers.extend([
        positive_peer.model_copy(update={"code": "605001"}),
        positive_peer.model_copy(update={"code": "605002"}),
    ])
    context.snapshot = context.snapshot.model_copy(update={"pct_change": 3.0})
    context.intraday_bars = [
        bar.model_copy(update={"volume": 100_000})
        if 180 <= bar.minutes_after_open < 195 else bar
        for bar in context.intraday_bars
    ]

    signal = strategy.evaluate_context(context)

    assert signal.eligible is False
    assert "未出现明显缩量回踩" in signal.reason


def test_p1_requires_price_above_vwap_for_most_of_the_day(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    positive_peer = context.sector_peers[-1]
    context.sector_peers.extend([
        positive_peer.model_copy(update={"code": "605001"}),
        positive_peer.model_copy(update={"code": "605002"}),
    ])
    context.snapshot = context.snapshot.model_copy(update={"pct_change": 3.0})
    context.intraday_bars = [
        bar.model_copy(update={"price": bar.avg_price * 0.99})
        if bar.minutes_after_open < 180 else bar
        for bar in context.intraday_bars
    ]

    signal = strategy.evaluate_context(context)

    assert signal.eligible is False
    assert "全天站上均价线占比" in signal.reason


def test_p1_requires_latest_price_in_upper_quarter_of_intraday_range(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()
    context = contexts["002833"]
    positive_peer = context.sector_peers[-1]
    context.sector_peers.extend([
        positive_peer.model_copy(update={"code": "605001"}),
        positive_peer.model_copy(update={"code": "605002"}),
    ])
    context.snapshot = context.snapshot.model_copy(update={"pct_change": 3.0})
    intraday_low = min(bar.price for bar in context.intraday_bars)
    context.intraday_bars[-1] = context.intraday_bars[-1].model_copy(
        update={"price": intraday_low + 0.01}
    )

    signal = strategy.evaluate_context(context)

    assert signal.eligible is False
    assert "日内振幅上方四分之一" in signal.reason


def test_sample_data_contains_end_to_end_default_p1_candidate(contexts) -> None:
    strategy = SectorResonancePullbackStrategy()

    eligible_codes = {
        code for code, context in contexts.items()
        if strategy.evaluate_context(context).eligible
    }

    assert "605000" in eligible_codes


def test_p1_service_only_enriches_sector_prefilter_candidates() -> None:
    from app.repository import StrategyRepository
    from app.service import StrategyService

    class CountingHistory(SampleHistoryProvider):
        def __init__(self) -> None:
            self.codes: list[str] = []

        def fetch(self, code, end, *, limit=30):
            self.codes.append(code)
            return super().fetch(code, end, limit=limit)

    class CountingIntraday(SampleIntradayProvider):
        def __init__(self) -> None:
            self.codes: list[str] = []

        def fetch(self, code, captured_at):
            self.codes.append(code)
            return super().fetch(code, captured_at)

    history = CountingHistory()
    intraday = CountingIntraday()
    repository = StrategyRepository(db_path=":memory:")
    repository.save_run = lambda *_, **__: None
    service = StrategyService(
        SectorResonancePullbackStrategy(),
        repository,
        history=history,
        intraday=intraday,
        sectors=SampleSectorProvider(),
    )

    service.run(
        SampleProvider(), mode="sample", observed_at=datetime(2026, 7, 31, 14, 50)
    )

    assert history.codes == []
    assert set(intraday.codes) == {"605000", "605001", "605002"}


def test_p1_sample_run_replays_tail_window_even_when_requested_in_morning() -> None:
    from app.repository import StrategyRepository
    from app.service import StrategyService

    repository = StrategyRepository(db_path=":memory:")
    repository.save_run = lambda *_, **__: None
    service = StrategyService(
        SectorResonancePullbackStrategy(),
        repository,
        history=SampleHistoryProvider(),
        intraday=SampleIntradayProvider(),
        sectors=SampleSectorProvider(),
    )

    run = service.run(
        SampleProvider(), mode="sample", observed_at=datetime(2026, 7, 31, 10, 0)
    )

    assert [signal.code for signal in run.signals] == ["605000"]
    assert run.observed_at.hour == 14
    assert run.observed_at.minute == 50


# ---------------------------------------------------------------------------
# P2
# ---------------------------------------------------------------------------

def test_p2_trend_pullback_uses_history_and_intraday(contexts) -> None:
    strategy = TrendPullbackStrategy()
    signal = strategy.evaluate_context(contexts["003010"])
    assert any(factor.key == "ma_alignment" for factor in signal.factors)
    assert any(factor.key == "platform_band" for factor in signal.factors)
    assert signal.priority_tags[0].status in {"matched", "partial"}
    assert signal.priority_tags[0].evidence


def test_p2_reports_missing_data_without_history() -> None:
    strategy = TrendPullbackStrategy()
    snapshot = MarketSnapshot(
        code="888888",
        name="无历史样例",
        price=10.0,
        pct_change=-3.0,
        day_low=9.8,
        turnover_rate=2.0,
        volume_ratio=1.0,
        market_pct_change=-1.0,
        captured_at=datetime(2026, 7, 31, 14, 50),
    )
    from app.models import MarketContext
    context = MarketContext(snapshot=snapshot)
    signal = strategy.evaluate_context(context)
    assert signal.eligible is False
    assert signal.priority_tags[0].status == "missing_data"


# ---------------------------------------------------------------------------
# P3
# ---------------------------------------------------------------------------

def test_p3_breakout_uses_platform_and_intraday(contexts) -> None:
    strategy = PlatformBreakoutStrategy()
    signal = strategy.evaluate_context(contexts["002833"])
    factor_keys = {factor.key for factor in signal.factors}
    assert {"platform_range", "breakout_hold_minutes", "volume_multiple", "upper_shadow"}.issubset(factor_keys)
    assert signal.priority_tags[0].status in {"matched", "partial"}
    assert signal.priority_tags[0].evidence


def test_p3_reports_missing_when_intraday_unavailable(contexts) -> None:
    strategy = PlatformBreakoutStrategy()
    contexts["002833"].intraday_bars = []
    signal = strategy.evaluate_context(contexts["002833"])
    assert signal.eligible is False
    assert signal.priority_tags[0].status == "missing_data"
    assert "分时" in signal.priority_tags[0].evidence[0]


# ---------------------------------------------------------------------------
# P4
# ---------------------------------------------------------------------------

def test_p4_leader_signal_uses_sector_and_intraday(contexts) -> None:
    strategy = LeaderReconvergenceStrategy()
    leader_signal = strategy.evaluate_context(contexts["000859"])
    factor_keys = {factor.key for factor in leader_signal.factors}
    assert {"is_leader", "limit_up_status", "seal_trend", "sector_vs_market"}.issubset(factor_keys)
    assert leader_signal.priority_tags[0].status in {"matched", "partial"}
    assert leader_signal.priority_tags[0].evidence


def test_p4_rejects_isolated_limit_up_without_sector_support(contexts) -> None:
    strategy = LeaderReconvergenceStrategy()
    contexts["600872"].sector = None
    contexts["600872"].sector_peers = []
    signal = strategy.evaluate_context(contexts["600872"])
    assert signal.eligible is False
    assert signal.priority_tags[0].status == "missing_data"


# ---------------------------------------------------------------------------
# 服务端串联：保证 V1 + P1–P4 都能落库
# ---------------------------------------------------------------------------

def test_service_runs_all_strategies_against_same_context() -> None:
    import os
    import tempfile
    from app.repository import StrategyRepository
    from app.service import StrategyService
    from app.strategies import ALL_STRATEGIES

    db_file = tempfile.NamedTemporaryFile(
        prefix="tail-stock-lab-test-",
        suffix=".db",
        dir=os.path.dirname(__file__),
        delete=False,
    )
    db_file.close()
    try:
        repository = StrategyRepository(db_path=db_file.name)
        services = {
            sid: StrategyService(cls(), repository) for sid, cls in ALL_STRATEGIES.items()
        }

        observed_at = datetime(2026, 7, 31, 14, 50)
        runs = {}
        for sid, service in services.items():
            runs[sid] = service.run(SampleProvider(), mode="sample", observed_at=observed_at)

        assert len(runs) == len(ALL_STRATEGIES)
        for sid, run in runs.items():
            assert run.strategy_id == sid
            # 哪怕没有 candidate，universe 必须存档，否则回测拿不到截面。
            assert run.universe_size == len(SampleProvider().fetch(observed_at))
    finally:
        try:
            os.unlink(db_file.name)
        except OSError:
            pass


def test_history_provider_returns_deterministic_sample() -> None:
    provider = SampleHistoryProvider()
    today = date(2026, 7, 31)
    bars = provider.fetch("002833", today, limit=20)
    assert len(bars) == 20
    again = provider.fetch("002833", today, limit=20)
    assert [bar.close for bar in bars] == [bar.close for bar in again]
