from __future__ import annotations

import sys
from datetime import datetime
from types import SimpleNamespace

import pandas as pd
import pytest

from app.data_provider import AkshareIntradayProvider, AkshareSectorProvider


def test_sector_provider_builds_stock_membership_from_board_codes(monkeypatch) -> None:
    requested_symbols: list[str] = []

    def industry_names() -> pd.DataFrame:
        return pd.DataFrame([
            {"板块代码": "BK0001", "板块名称": "强势板块", "涨跌幅": 2.6,
             "领涨股票": "甲公司", "领涨股票-涨跌幅": 5.2},
            {"板块代码": "BK0002", "板块名称": "次强板块", "涨跌幅": 1.1,
             "领涨股票": "乙公司", "领涨股票-涨跌幅": 3.4},
        ])

    def industry_members(symbol: str) -> pd.DataFrame:
        requested_symbols.append(symbol)
        members = {
            "BK0001": [{"代码": "000001", "名称": "甲公司"}],
            "BK0002": [{"代码": "600001", "名称": "乙公司"}],
        }
        return pd.DataFrame(members[symbol])

    monkeypatch.setitem(sys.modules, "akshare", SimpleNamespace(
        stock_board_industry_name_em=industry_names,
        stock_board_industry_cons_em=industry_members,
    ))

    provider = AkshareSectorProvider()

    assert provider.sector_for_code("000001").code == "BK0001"
    assert provider.sector_for_code("600001").code == "BK0002"
    assert set(requested_symbols) == {"BK0001", "BK0002"}


def test_intraday_provider_calculates_cumulative_vwap_from_amount_and_volume(monkeypatch) -> None:
    frame = pd.DataFrame([
        {"时间": "2026-07-31 09:30:00", "收盘": 10.0, "成交量": 10, "成交额": 10_000},
        {"时间": "2026-07-31 09:31:00", "收盘": 12.0, "成交量": 20, "成交额": 24_000},
    ])
    monkeypatch.setitem(sys.modules, "akshare", SimpleNamespace(
        stock_zh_a_hist_min_em=lambda **_: frame.copy(),
    ))

    bars = AkshareIntradayProvider().fetch(
        "000001", datetime(2026, 7, 31, 9, 31)
    )

    assert [bar.avg_price for bar in bars] == [10.0, pytest.approx(11.333333, rel=1e-6)]
