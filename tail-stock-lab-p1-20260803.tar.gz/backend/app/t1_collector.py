from __future__ import annotations

from datetime import datetime

import requests

from app.backtest import simulate_t1_exit
from app.models import NextDayPath, PaperTrade, Signal
from app.repository import StrategyRepository


class TencentT1PathProvider:
    """Fetch the next available trading day's minute path for a stored signal."""

    source_name = "Tencent minute path"

    @staticmethod
    def _symbol(code: str) -> str:
        return ("sh" if code.startswith("6") else "sz") + code

    @staticmethod
    def parse_next_path(signal: Signal, payload: dict) -> NextDayPath | None:
        try:
            days = payload["data"][TencentT1PathProvider._symbol(signal.code)]["data"]
        except KeyError as exc:
            raise RuntimeError(f"腾讯分钟行情未包含 {signal.code}") from exc
        signal_date = signal.snapshot.captured_at.date()
        next_days = [day for day in days if datetime.strptime(day["date"], "%Y%m%d").date() > signal_date]
        if not next_days:
            return None
        day = min(next_days, key=lambda item: item["date"])
        prices = []
        for bar in day["data"]:
            parts = bar.split()
            if len(parts) >= 2 and "0930" <= parts[0] <= "1030":
                try:
                    prices.append(float(parts[1]))
                except ValueError:
                    continue
        if not prices:
            return None
        return NextDayPath(
            code=signal.code,
            entry_price=signal.snapshot.price,
            prices=prices,
            observed_at=datetime.strptime(day["date"], "%Y%m%d"),
        )

    def fetch(self, signal: Signal) -> NextDayPath | None:
        response = requests.get(
            f"https://web.ifzq.gtimg.cn/appstock/app/day/query?code={self._symbol(signal.code)}",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=15,
        )
        response.raise_for_status()
        return self.parse_next_path(signal, response.json())


class T1OutcomeCollector:
    def __init__(self, repository: StrategyRepository, provider: TencentT1PathProvider | None = None) -> None:
        self.repository = repository
        self.provider = provider or TencentT1PathProvider()

    def collect_due(self, as_of: datetime | None = None) -> list[PaperTrade]:
        as_of = as_of or datetime.now()
        trades: list[PaperTrade] = []
        for run_id, signal in self.repository.pending_t1_signals(as_of.date().isoformat()):
            path = self.provider.fetch(signal)
            if path is None:
                continue
            trade = simulate_t1_exit(signal, path)
            self.repository.save_t1_outcome(run_id, path.observed_at.date().isoformat(), trade)
            trades.append(trade)
        return trades
