from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.backtest import summarize_backtest
from app.data_provider import (
    AkshareHistoryProvider,
    AkshareIntradayProvider,
    AkshareSectorProvider,
    LiveSpotProvider,
    SampleHistoryProvider,
    SampleIntradayProvider,
    SampleProvider,
    SampleSectorProvider,
)
from app.models import NextDayPath
from app.repository import StrategyRepository
from app.service import StrategyService
from app.strategies import (
    ALL_STRATEGIES,
    FishingV1Strategy,
    LeaderReconvergenceStrategy,
    PlatformBreakoutStrategy,
    SectorResonancePullbackStrategy,
    TrendPullbackStrategy,
)
from app.t1_collector import T1OutcomeCollector

repository = StrategyRepository()

STRATEGY_INSTANCES = {
    strategy_id: cls()
    for strategy_id, cls in ALL_STRATEGIES.items()
}

services: dict[str, StrategyService] = {
    strategy_id: StrategyService(
        instance,
        repository,
        history=SampleHistoryProvider(),
        intraday=SampleIntradayProvider(),
        sectors=SampleSectorProvider(),
    )
    for strategy_id, instance in STRATEGY_INSTANCES.items()
}

app = FastAPI(title="tail-stock-lab", version="0.2.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["*"], allow_headers=["*"])


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "strategies": [sid for sid in STRATEGY_INSTANCES],
        "default_strategy": FishingV1Strategy.strategy_id,
    }


@app.get("/api/strategies")
def list_strategies() -> dict:
    return {
        "strategies": [
            {**instance.definition(), "config": instance.current_config()}
            for instance in STRATEGY_INSTANCES.values()
        ]
    }


@app.get("/api/strategies/{strategy_id}/config")
def strategy_config(strategy_id: str) -> dict:
    instance, _ = _resolve(strategy_id)
    return {"strategy_id": strategy_id, "config": instance.current_config()}


@app.post("/api/strategies/{strategy_id}/config")
def update_strategy_config(strategy_id: str, payload: dict) -> dict:
    """用 dict 部分覆盖策略 config；非法字段忽略。"""
    instance, _ = _resolve(strategy_id)
    overrides = payload.get("overrides") if isinstance(payload, dict) else None
    new_instance = instance.with_overrides(overrides or {})
    STRATEGY_INSTANCES[strategy_id] = new_instance
    services[strategy_id] = StrategyService(
        new_instance, repository,
        history=SampleHistoryProvider(),
        intraday=SampleIntradayProvider(),
        sectors=SampleSectorProvider(),
    )
    return {"strategy_id": strategy_id, "config": new_instance.current_config()}


def _resolve(strategy_id: str) -> tuple[object, StrategyService]:
    if strategy_id not in STRATEGY_INSTANCES:
        raise HTTPException(status_code=404, detail="策略不存在")
    return STRATEGY_INSTANCES[strategy_id], services[strategy_id]


@app.get("/api/strategies/{strategy_id}/latest")
def latest(strategy_id: str):
    _, _service = _resolve(strategy_id)
    return repository.latest_run(strategy_id)


@app.post("/api/strategies/{strategy_id}/run")
def run_strategy(strategy_id: str, mode: str = Query("sample", pattern="^(sample|live)$")):
    instance, service = _resolve(strategy_id)
    if mode == "live":
        service = StrategyService(
            instance,
            repository,
            history=AkshareHistoryProvider(),
            intraday=AkshareIntradayProvider(),
            sectors=AkshareSectorProvider(),
        )
    try:
        run = service.run(
            SampleProvider() if mode == "sample" else LiveSpotProvider(),
            mode=mode,
        )
        if run.execution_status == "tradable" and not run.signals:
            setattr(run, "empty_alert", "可执行时段无候选；可能筛选过严或市场无满足条件的票。")
        return run
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"策略运行失败：{exc}") from exc


@app.post("/api/strategies/{strategy_id}/preview")
def preview_strategy(strategy_id: str, mode: str = Query("sample", pattern="^(sample|live)$")):
    """无论是否尾盘都跑一遍，返回合格候选 + 接近合格的近失分样本，方便调参。"""
    instance, _ = _resolve(strategy_id)
    service = StrategyService(
        instance, repository,
        history=SampleHistoryProvider(),
        intraday=SampleIntradayProvider(),
        sectors=SampleSectorProvider(),
    )
    try:
        return service.preview(
            SampleProvider() if mode == "sample" else LiveSpotProvider(),
            mode=mode,
        )
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"预览失败：{exc}") from exc


@app.post("/api/strategies/run-all")
def run_all_strategies(mode: str = Query("sample", pattern="^(sample|live)$")):
    """对所有 P1-P4 + V1 同时跑一次，结果横向对比。"""
    try:
        snapshots = SampleProvider() if mode == "sample" else LiveSpotProvider()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"行情获取失败：{exc}") from exc

    if mode == "live":
        for strategy_id in STRATEGY_INSTANCES:
            services[strategy_id] = StrategyService(
                STRATEGY_INSTANCES[strategy_id],
                repository,
                history=AkshareHistoryProvider(),
                intraday=AkshareIntradayProvider(),
                sectors=AkshareSectorProvider(),
            )

    results: dict[str, dict] = {}
    for strategy_id, service in services.items():
        try:
            run = service.run(snapshots, mode=mode)
            results[strategy_id] = run.model_dump(mode="json")
        except Exception as exc:
            results[strategy_id] = {"error": str(exc), "strategy_id": strategy_id}
    return {"runs": results, "mode": mode}


@app.post("/api/strategies/{strategy_id}/backtest/sample")
def sample_backtest(strategy_id: str):
    """仅用于展示回测口径；真实历史回测必须由已存档的尾盘快照驱动。"""
    _, service = _resolve(strategy_id)
    run = service.run(SampleProvider(), mode="sample")
    paths = [
        NextDayPath(code="002833", entry_price=16.22, prices=[16.26, 16.43, 16.37, 16.31], observed_at=run.observed_at),
        NextDayPath(code="003010", entry_price=28.65, prices=[28.59, 28.72, 28.96, 28.74], observed_at=run.observed_at),
        NextDayPath(code="603617", entry_price=8.72, prices=[8.66, 8.51, 8.43, 8.47], observed_at=run.observed_at),
    ]
    return summarize_backtest(run.signals, paths, mode="sample")


@app.post("/api/backtests/t1/collect")
def collect_t1_outcomes() -> dict:
    trades = T1OutcomeCollector(repository).collect_due()
    return {"collected": len(trades), "trades": trades}


@app.get("/api/backtests/t1/recent")
def recent_t1_outcomes() -> dict:
    trades = repository.recent_t1_outcomes()
    return {"trade_count": len(trades), "trades": trades}


web_dir = Path(__file__).resolve().parents[1] / "web"
if web_dir.is_dir():
    app.mount("/", StaticFiles(directory=web_dir, html=True), name="web")
