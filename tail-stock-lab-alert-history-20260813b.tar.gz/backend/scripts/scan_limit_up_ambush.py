"""Continuously publish the latest two-minute intraday alert scan.

Only a small set of eligible alerts is persisted.  The full market snapshot is
used in memory for the scan but intentionally not written every two minutes.
"""

from __future__ import annotations

import sys
import time as clock
from datetime import datetime, time
from pathlib import Path
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.data_provider import LiveSectorProvider, LiveSpotProvider
from app.repository import StrategyRepository
from app.service import StrategyService
from app.strategies.limit_up_ambush import LimitUpAmbushAlertStrategy

SCAN_SECONDS = 120


class _SnapshotBatchProvider:
    def __init__(self, snapshots, source_name: str) -> None:
        self.snapshots = snapshots
        self.source_name = source_name

    def fetch(self, _observed_at):
        return self.snapshots


def _is_tracking_window(observed_at: datetime) -> bool:
    local = observed_at.astimezone(ZoneInfo("Asia/Shanghai")) if observed_at.tzinfo else observed_at
    if local.weekday() >= 5:
        return False
    now = local.time()
    return time(9, 35) <= now <= time(11, 30) or time(13, 0) <= now <= time(15, 0)


def run_once(
    *,
    observed_at: datetime | None = None,
    repository: StrategyRepository | None = None,
    live: LiveSpotProvider | None = None,
    sectors: LiveSectorProvider | None = None,
    snapshots=None,
):
    observed_at = observed_at or datetime.now(ZoneInfo("Asia/Shanghai"))
    strategy = LimitUpAmbushAlertStrategy()
    if not strategy.is_executable_at(observed_at):
        return None
    repository = repository or StrategyRepository()
    live = live or LiveSpotProvider()
    sectors = sectors or LiveSectorProvider()
    service = StrategyService(strategy, repository, sectors=sectors)
    provider = _SnapshotBatchProvider(snapshots, live.source_name) if snapshots is not None else live
    run = service.run(
        provider,
        mode="live",
        observed_at=observed_at,
        capture_origin="scheduled",
        persist_snapshots=False,
    )
    repository.record_alert_run(run)
    return run


def run_cycle(
    *,
    observed_at: datetime | None = None,
    repository: StrategyRepository | None = None,
    live: LiveSpotProvider | None = None,
    sectors: LiveSectorProvider | None = None,
):
    """Run a new alert scan or continue tracking today's prior alerts."""
    observed_at = observed_at or datetime.now(ZoneInfo("Asia/Shanghai"))
    repository = repository or StrategyRepository()
    live = live or LiveSpotProvider()
    strategy = LimitUpAmbushAlertStrategy()
    alert_date = observed_at.date().isoformat()
    should_scan = strategy.is_executable_at(observed_at)
    should_track = (
        _is_tracking_window(observed_at)
        and repository.has_alert_events(strategy.strategy_id, alert_date)
    )
    if not should_scan and not should_track:
        return None

    snapshots = live.fetch(observed_at)
    run = None
    if should_scan:
        run = run_once(
            observed_at=observed_at,
            repository=repository,
            live=live,
            sectors=sectors,
            snapshots=snapshots,
        )
    finalize = observed_at.time() >= time(14, 57)
    tracked_count = repository.update_alert_outcomes(
        strategy.strategy_id,
        observed_at,
        snapshots,
        finalize=finalize,
    )
    return {"run": run, "tracked_count": tracked_count, "finalized": finalize}


def main() -> int:
    # Reuse the sector provider for the process lifetime so its membership map
    # is cached; live quotes still refresh every scan.
    repository = StrategyRepository()
    live = LiveSpotProvider()
    sectors = LiveSectorProvider()
    while True:
        try:
            cycle = run_cycle(repository=repository, live=live, sectors=sectors)
            if cycle is None:
                print("skip: outside intraday alert windows", flush=True)
            else:
                run = cycle["run"]
                print(
                    f"alert-cycle run={run.run_id if run else '-'} "
                    f"source={run.data_source if run else live.source_name} "
                    f"universe={run.universe_size if run else '-'} "
                    f"alerts={len(run.signals) if run else 0} "
                    f"tracked={cycle['tracked_count']} finalized={cycle['finalized']}",
                    flush=True,
                )
        except Exception as exc:
            # A source outage is visible in journal logs but the next scan is
            # still attempted; it must never affect the tail snapshot timers.
            print(f"alert-scan failed error={exc}", file=sys.stderr, flush=True)
        clock.sleep(SCAN_SECONDS)


if __name__ == "__main__":
    raise SystemExit(main())
