import assert from 'node:assert/strict'
import test from 'node:test'

import { loadAlertHistory, loadAllHistory, loadHistoricalRun, loadHistory, loadLatestAlert, loadT1Review, runStrategy } from './api.js'

test('runStrategy requests a live snapshot for the currently selected strategy', async () => {
  let requestedPath = null
  globalThis.fetch = async (path) => {
    requestedPath = path
    return { ok: true, json: async () => ({}) }
  }

  await runStrategy('p1-sector-resonance')

  assert.equal(
    requestedPath,
    '/api/strategies/p1-sector-resonance/run?mode=live',
  )
})

test('loadHistory omits empty params and preserves filled ones', async () => {
  let requestedPath = null
  globalThis.fetch = async (path) => {
    requestedPath = path
    return { ok: true, json: async () => ({ runs: [] }) }
  }

  await loadHistory('fishing-reversal', { date_from: '2026-08-01', date_to: '' })
  assert.equal(requestedPath, '/api/strategies/fishing-reversal/history?date_from=2026-08-01')

  await loadAllHistory({ date_from: '2026-08-01', date_to: '2026-08-03' })
  assert.equal(
    requestedPath,
    '/api/strategies/history?date_from=2026-08-01&date_to=2026-08-03',
  )

  await loadHistoricalRun('fishing-reversal', 'run-abc')
  assert.equal(requestedPath, '/api/strategies/fishing-reversal/run/run-abc')
})

test('loadT1Review requests the latest completed review for a strategy', async () => {
  let requestedPath = null
  globalThis.fetch = async (path) => {
    requestedPath = path
    return { ok: true, json: async () => ({ reviews: [] }) }
  }

  await loadT1Review('fishing-reversal')

  assert.equal(requestedPath, '/api/strategies/fishing-reversal/t1-review/latest')
})

test('loadLatestAlert requests the independent intraday alert feed', async () => {
  let requestedPath = null
  globalThis.fetch = async (path) => {
    requestedPath = path
    return { ok: true, json: async () => ({}) }
  }

  await loadLatestAlert()

  assert.equal(requestedPath, '/api/strategies/limit-up-ambush/latest')
})

test('loadAlertHistory requests the deduplicated alert event view with filters', async () => {
  let requestedPath = null
  globalThis.fetch = async (path) => {
    requestedPath = path
    return { ok: true, json: async () => ({ events: [] }) }
  }

  await loadAlertHistory({ date: '2026-08-13', result: 'hit_limit', persistent_only: true })

  assert.equal(
    requestedPath,
    '/api/strategies/limit-up-ambush/alert-history?date=2026-08-13&result=hit_limit&persistent_only=true',
  )
})
