import { useEffect, useMemo, useState } from 'react'
import { loadLatest, loadStrategy, runStrategy, sampleBacktest } from './api'

const riskLabel = { low: '低', medium: '中等', high: '较高' }
const exitLabel = { stop_loss: '触发风险线', trailing_exit: '回撤止盈', morning_cutoff: '上午截止' }
const tagStatusLabel = { partial: '部分符合', missing_data: '待验证', excluded: '非主策略' }

function PrimaryTag({ tags = [] }) {
  const tag = tags.find((item) => item.key === 'sector_resonance_pullback')
  if (!tag) return <span className="tag-chip missing_data">新快照后生成</span>
  return <span className={`tag-chip ${tag.status}`}>P{tag.priority} · {tagStatusLabel[tag.status]}</span>
}

function PriorityTags({ tags = [] }) {
  if (!tags.length) return <p className="muted tag-empty">这是旧快照；重新运行后会生成优先级标签。</p>
  return <div className="priority-tags">{tags.map((tag) => <div className="priority-tag" key={tag.key}>
    <div><strong>P{tag.priority} {tag.label}</strong><span className={`tag-chip ${tag.status}`}>{tagStatusLabel[tag.status]}</span></div>
    <ul>{tag.evidence.map((item) => <li key={item}>{item}</li>)}</ul>
  </div>)}</div>
}

function formatTime(value) {
  return value ? new Date(value).toLocaleString('zh-CN', { hour12: false }) : '尚未运行'
}

export default function App() {
  const [definition, setDefinition] = useState(null)
  const [run, setRun] = useState(null)
  const [selected, setSelected] = useState(null)
  const [backtest, setBacktest] = useState(null)
  const [status, setStatus] = useState('正在加载策略定义…')
  const [running, setRunning] = useState(false)

  useEffect(() => {
    Promise.all([loadStrategy(), loadLatest().catch(() => null)])
      .then(([catalog, latest]) => {
        setDefinition(catalog.strategies[0])
        setRun(latest)
        setSelected(latest?.signals?.[0] ?? null)
        setStatus(latest ? '已读取最近一次研究快照' : '尚无快照：可先运行研究样例')
      })
      .catch((error) => setStatus(error.message))
  }, [])

  const stats = useMemo(() => ({
    candidates: run?.signals?.length ?? 0,
    universe: run?.universe_size ?? 0,
    observed: formatTime(run?.observed_at),
  }), [run])

  async function execute(mode) {
    setRunning(true)
    try {
      const nextRun = await runStrategy(mode)
      setRun(nextRun)
      setSelected(nextRun.signals?.[0] ?? null)
      setStatus(mode === 'live' ? '实时快照已运行；请先核验数据时点再研究。' : '研究样例已运行，不代表真实市场表现。')
    } catch (error) {
      setStatus(error.message)
    } finally {
      setRunning(false)
    }
  }

  async function inspectBacktest() {
    setRunning(true)
    try {
      setBacktest(await sampleBacktest())
      setStatus('已生成回测口径示例：盈亏平衡触及与规则化净收益分开统计。')
    } catch (error) {
      setStatus(error.message)
    } finally {
      setRunning(false)
    }
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand">尾盘策略实验室</div>
      <nav>
        <a href="#strategy" className="active">策略实验室</a>
        <a href="#backtest">T+1 回测</a>
        <a href="#history">信号历史</a>
      </nav>
      <div className="sidebar-note">仅研究，不构成投资建议</div>
    </aside>
    <main className="workspace">
      <header className="topbar"><span>研究快照</span><strong>{stats.observed}</strong><span className="dot" /> <span>{run?.mode === 'live' ? (run?.execution_status === 'tradable' ? '实时数据 · 可执行时段' : '实时数据 · 非可执行时段') : '研究样例'}</span><span className="source-tag">{run?.data_source ?? '等待数据源'}</span></header>
      <section id="strategy" className="headline">
        <div><h1>{definition?.name ?? '尾盘恐慌止跌'} <span>· V1</span></h1><p>{definition?.summary ?? '加载中'}</p></div>
        <div className="actions"><button disabled={running} onClick={() => execute('sample')}>运行研究样例</button><button className="primary" disabled={running} onClick={() => execute('live')}>运行实时快照</button></div>
      </section>
      <p className="risk-copy">风险提示：策略只生成可研究的候选，不能保证次日盈利；隔夜跳空可能使风险线失效。</p>
      <p className="status-line" role="status">{status}</p>

      <section className="summary-strip"><div><span>候选信号</span><strong>{stats.candidates}</strong></div><div><span>扫描范围</span><strong>{stats.universe || '—'}</strong></div><div><span>执行时段</span><strong>{definition?.execution_window ?? '14:30–15:00'}</strong></div></section>

      <section className="content-grid">
        <div className="signal-area">
          <div className="section-heading"><h2>候选池</h2><span>按尾盘评分排序；标签不是买入建议</span></div>
          <div className="table-wrap"><table><thead><tr><th>排名</th><th>股票</th><th>尾盘评分</th><th>优先级标签</th><th>日内下跌</th><th>低点回升</th><th>相对强度</th><th>风险</th></tr></thead><tbody>
            {run?.signals?.length ? run.signals.map((signal, index) => <tr key={signal.code} onClick={() => setSelected(signal)} className={selected?.code === signal.code ? 'selected-row' : ''}>
              <td>{index + 1}</td><td><strong>{signal.code} {signal.name}</strong><small>{signal.reason}</small></td><td className="score">{signal.score}</td><td><PrimaryTag tags={signal.priority_tags} /></td><td>{signal.factors.find((x) => x.key === 'decline')?.value}%</td><td>{signal.factors.find((x) => x.key === 'rebound')?.value}%</td><td>{signal.factors.find((x) => x.key === 'relative_strength')?.value}%</td><td className={`risk ${signal.risk_level}`}>{riskLabel[signal.risk_level]}</td>
            </tr>) : <tr><td colSpan="8" className="empty">尚无候选。研究样例可验证流程；实时快照仅应在尾盘数据可用时运行。</td></tr>}
          </tbody></table></div>
        </div>
        <aside className="inspector"><h2>信号详情</h2>{selected ? <><h3>{selected.code} {selected.name}</h3><p className="muted">评分 {selected.score} · 风险 {riskLabel[selected.risk_level]}</p><div className="factor-list">{selected.factors.map((factor) => <div key={factor.key}><span>{factor.label}<small>{factor.description}</small></span><strong>{factor.value}<em> +{factor.score}</em></strong></div>)}</div><h4 className="tag-heading">优先级策略适配</h4><PriorityTags tags={selected.priority_tags} /><p className="rule-note">{definition?.risk_rule}</p></> : <p className="muted">选择一条候选信号查看因子拆解。</p>}</aside>
      </section>

      <section id="backtest" className="backtest-band"><div className="section-heading"><div><h2>T+1 是否可盈利离场</h2><span>以实际可执行价格路径，不以次日最高价倒推</span></div><button disabled={running} onClick={inspectBacktest}>查看口径示例</button></div>
        {backtest ? <><div className="backtest-metrics"><div><span>触及盈亏平衡率</span><strong>{backtest.touched_breakeven_rate}%</strong></div><div><span>规则化盈利退出率</span><strong>{backtest.profitable_exit_rate}%</strong></div><div><span>平均净收益</span><strong>{backtest.average_net_return_pct}%</strong></div></div><div className="trade-list">{backtest.trades.map((trade) => <div key={trade.code}><strong>{trade.code} {trade.name}</strong><span>{trade.profitable_exit ? '可盈利退出' : '未盈利退出'}</span><em>{trade.net_return_pct}% · {exitLabel[trade.exit_reason]}</em></div>)}</div></> : <p className="muted">V1 会同时展示“是否触及盈亏平衡”和“按固定规则实际退出是否盈利”。真实回测需积累带时间戳的尾盘快照与次日分钟路径。</p>}
      </section>
    </main>
  </div>
}
