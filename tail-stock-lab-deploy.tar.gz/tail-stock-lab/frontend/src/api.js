export async function request(path, options) {
  const response = await fetch(path, options)
  if (!response.ok) {
    const payload = await response.json().catch(() => ({}))
    throw new Error(payload.detail || '服务暂不可用')
  }
  return response.json()
}

export const loadStrategy = () => request('/api/strategies')
export const loadLatest = () => request('/api/strategies/fishing-reversal/latest')
export const runStrategy = (mode) => request(`/api/strategies/fishing-reversal/run?mode=${mode}`, { method: 'POST' })
export const sampleBacktest = () => request('/api/strategies/fishing-reversal/backtest/sample', { method: 'POST' })

