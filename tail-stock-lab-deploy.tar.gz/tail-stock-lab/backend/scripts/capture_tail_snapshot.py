"""Cron-friendly tail-session snapshot capture.

Run this script at 14:50 Asia/Shanghai on trading days.  It fails closed outside
the strategy's declared execution window, so a late manual run cannot silently
produce a tradable signal from stale end-of-day data.
"""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.data_provider import LiveSpotProvider
from app.repository import StrategyRepository
from app.service import StrategyService
from app.strategies.fishing_v1 import FishingV1Strategy


def main() -> int:
    observed_at = datetime.now(ZoneInfo("Asia/Shanghai"))
    if not StrategyService._is_tail_window(observed_at):
        print("skip: only capture a tradable snapshot between 14:30 and 15:00 Asia/Shanghai")
        return 2

    service = StrategyService(FishingV1Strategy(), StrategyRepository())
    run = service.run(LiveSpotProvider(), mode="live", observed_at=observed_at)
    print(
        f"captured run={run.run_id} source={run.data_source} "
        f"universe={run.universe_size} signals={len(run.signals)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
