from datetime import datetime

from app.backtest import ExecutionPolicy, simulate_t1_exit, summarize_backtest
from app.data_provider import SampleProvider
from app.models import MarketSnapshot, NextDayPath
from app.service import StrategyService
from app.strategies.fishing_v1 import FishingV1Strategy
from app.t1_collector import TencentT1PathProvider


def _signal():
    snapshot = MarketSnapshot(
        code="000001", name="样例", price=10, pct_change=-4, day_low=9.8,
        turnover_rate=3, volume_ratio=1.5, market_pct_change=-1, captured_at=datetime(2026, 7, 1, 14, 50),
    )
    return FishingV1Strategy().evaluate(snapshot)


def test_t1_profit_requires_executable_rule_exit_not_just_peak() -> None:
    trade = simulate_t1_exit(
        _signal(),
        NextDayPath(code="000001", entry_price=10, prices=[10.03, 10.20, 10.12], observed_at=datetime.now()),
    )
    assert trade.touched_breakeven is True
    assert trade.profitable_exit is True
    assert trade.exit_reason == "trailing_exit"


def test_stop_loss_records_actual_path_price_and_cost() -> None:
    trade = simulate_t1_exit(
        _signal(),
        NextDayPath(code="000001", entry_price=10, prices=[9.68], observed_at=datetime.now()),
        ExecutionPolicy(round_trip_cost_rate=0.0015, stop_loss_rate=0.03),
    )
    assert trade.exit_reason == "stop_loss"
    assert trade.profitable_exit is False
    assert trade.net_return_pct < -3


def test_summary_reports_breakeven_and_profit_as_separate_metrics() -> None:
    signal = _signal()
    summary = summarize_backtest(
        [signal],
        [NextDayPath(code="000001", entry_price=10, prices=[10.03, 9.7], observed_at=datetime.now())],
        mode="sample",
    )
    assert summary.touched_breakeven_rate == 100
    assert summary.profitable_exit_rate == 0


class _InMemoryRepository:
    def __init__(self) -> None:
        self.run = None
        self.snapshots = []

    def save_run(self, run, snapshots=None) -> None:
        self.run = run
        self.snapshots = snapshots or []

    def latest_run(self, _strategy_id):
        return self.run


def test_live_result_is_not_executable_outside_tail_window_and_keeps_source() -> None:
    service = StrategyService(FishingV1Strategy(), _InMemoryRepository())
    run = service.run(
        SampleProvider(),
        mode="live",
        observed_at=datetime(2026, 7, 31, 19, 0),
    )
    assert run.execution_status == "outside_tail_window"
    assert run.signals == []
    assert run.data_source == "内置研究样例"

    persisted = service.repository.latest_run("fishing-reversal")
    assert persisted is not None
    assert persisted.execution_status == "outside_tail_window"
    assert persisted.data_source == "内置研究样例"
    assert len(service.repository.snapshots) == 5


def test_live_result_is_executable_in_tail_window() -> None:
    service = StrategyService(FishingV1Strategy(), _InMemoryRepository())
    run = service.run(
        SampleProvider(),
        mode="live",
        observed_at=datetime(2026, 7, 31, 14, 45),
    )
    assert run.execution_status == "tradable"
    assert len(run.signals) == 3


def test_tencent_minute_path_uses_first_future_trading_day_and_morning_window() -> None:
    signal = _signal()
    payload = {
        "data": {
            "sz000001": {
                "data": [
                    {"date": "20260703", "data": ["0930 10.02 1 1", "1030 10.18 1 1", "1031 9.20 1 1"]},
                    {"date": "20260702", "data": ["0930 10.01 1 1", "0931 10.10 1 1", "1100 9.80 1 1"]},
                ]
            }
        }
    }
    path = TencentT1PathProvider.parse_next_path(signal, payload)
    assert path is not None
    assert path.observed_at.date().isoformat() == "2026-07-02"
    assert path.prices == [10.01, 10.1]


def test_signal_exposes_priority_tags_without_overclaiming_missing_data() -> None:
    tags = {tag.key: tag for tag in _signal().priority_tags}
    assert tags["sector_resonance_pullback"].status == "partial"
    assert tags["trend_pullback"].status == "missing_data"
    assert tags["tail_surge_only"].status == "excluded"
