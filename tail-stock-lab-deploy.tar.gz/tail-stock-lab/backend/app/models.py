from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class MarketSnapshot(BaseModel):
    code: str
    name: str
    price: float
    pct_change: float
    day_low: float
    turnover_rate: float = 0.0
    volume_ratio: float = 0.0
    market_pct_change: float = 0.0
    captured_at: datetime


class FactorContribution(BaseModel):
    key: str
    label: str
    value: float
    score: float
    description: str


class PriorityTag(BaseModel):
    key: str
    label: str
    priority: int
    status: Literal["partial", "missing_data", "excluded"]
    evidence: list[str]


class Signal(BaseModel):
    code: str
    name: str
    score: float = Field(ge=0, le=100)
    eligible: bool
    reason: str
    risk_level: Literal["low", "medium", "high"]
    factors: list[FactorContribution]
    snapshot: MarketSnapshot
    priority_tags: list[PriorityTag] = Field(default_factory=list)


class StrategyRun(BaseModel):
    run_id: str
    strategy_id: str
    version: str
    observed_at: datetime
    mode: Literal["live", "sample"]
    data_source: str = "unknown"
    execution_status: Literal["sample", "tradable", "outside_tail_window"] = "sample"
    universe_size: int
    signals: list[Signal]


class NextDayPath(BaseModel):
    """T+1 可交易时段的顺序价格路径；不能用当日最高价倒推成交。"""
    code: str
    entry_price: float
    prices: list[float]
    observed_at: datetime


class PaperTrade(BaseModel):
    code: str
    name: str
    entry_price: float
    exit_price: float
    net_return_pct: float
    touched_breakeven: bool
    profitable_exit: bool
    exit_reason: Literal["stop_loss", "trailing_exit", "morning_cutoff"]


class BacktestSummary(BaseModel):
    strategy_id: str
    version: str
    mode: Literal["sample", "historical"]
    trade_count: int
    touched_breakeven_rate: float
    profitable_exit_rate: float
    average_net_return_pct: float
    trades: list[PaperTrade]
