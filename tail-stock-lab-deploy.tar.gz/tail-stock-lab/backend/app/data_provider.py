from __future__ import annotations

import math
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Protocol
from zoneinfo import ZoneInfo

import requests

from app.models import MarketSnapshot


class MarketDataProvider(Protocol):
    source_name: str

    def fetch(self, captured_at: datetime) -> list[MarketSnapshot]: ...


def _number(value: object, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _tencent_index_quote() -> tuple[float, datetime]:
    """Return SSE Composite change and the source timestamp from Tencent quote."""
    response = requests.get(
        "https://qt.gtimg.cn/q=sh000001",
        headers={"User-Agent": "Mozilla/5.0"},
        timeout=12,
    )
    response.raise_for_status()
    try:
        fields = response.text.split('"')[1].split("~")
        source_at = datetime.strptime(fields[30], "%Y%m%d%H%M%S")
        now = datetime.now(ZoneInfo("Asia/Shanghai"))
        if source_at.date() != now.date():
            raise RuntimeError(f"腾讯指数行情不是当日数据（数据时点 {source_at:%Y-%m-%d %H:%M:%S}）")
        return _number(fields[32]), source_at
    except (IndexError, ValueError) as exc:
        raise RuntimeError("腾讯指数行情返回格式异常") from exc


def _tencent_index_change() -> float:
    return _tencent_index_quote()[0]


class AkshareSpotProvider:
    """Primary adapter: AkShare's Eastmoney A-share snapshot."""

    source_name = "AkShare / Eastmoney"

    def fetch(self, captured_at: datetime) -> list[MarketSnapshot]:
        try:
            import akshare as ak
        except ImportError as exc:  # pragma: no cover - deployment dependency
            raise RuntimeError("未安装 akshare，无法读取实时市场快照") from exc

        market_change = _tencent_index_change()
        frame = ak.stock_zh_a_spot_em()
        rows: list[MarketSnapshot] = []
        for _, row in frame.iterrows():
            try:
                code = str(row["代码"]).zfill(6)
                name = str(row["名称"])
                price = _number(row["最新价"])
                pct_change = _number(row["涨跌幅"])
                day_low = _number(row["最低"])
                turnover_rate = _number(row.get("换手率", 0))
                volume_ratio = _number(row.get("量比", 0))
            except KeyError:
                continue
            if price <= 0 or day_low <= 0 or name.startswith(("ST", "*ST")):
                continue
            rows.append(MarketSnapshot(
                code=code,
                name=name,
                price=price,
                pct_change=pct_change,
                day_low=day_low,
                turnover_rate=turnover_rate,
                volume_ratio=volume_ratio,
                market_pct_change=market_change,
                captured_at=captured_at,
            ))
        if not rows:
            raise RuntimeError("东财行情未返回可用 A 股快照")
        return rows


class TencentSinaSpotProvider:
    """Fallback adapter with two independent, live public quote sources.

    Tencent exposes turnover, volume ratio and percent change for the whole
    market. Sina exposes the intraday low. The two are joined by security code
    during one short snapshot window; no field is fabricated when Eastmoney is
    unavailable.
    """

    source_name = "Tencent + Sina composite"
    _headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://finance.sina.com.cn/"}
    _tencent_url = "https://proxy.finance.qq.com/cgi/cgi-bin/rank/hs/getBoardRankList"
    _sina_url = "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData"
    _sina_count_url = "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeStockCount?node=hs_a"

    @staticmethod
    def _request_json(url: str, *, params: dict[str, str] | None = None) -> object:
        response = requests.get(url, params=params, headers=TencentSinaSpotProvider._headers, timeout=15)
        response.raise_for_status()
        return response.json()

    def _fetch_tencent_rows(self) -> dict[str, dict]:
        params = {
            "_appver": "11.17.0",
            "board_code": "aStock",
            "sort_type": "price",
            "direct": "down",
            "offset": "0",
            "count": "200",
        }
        first = self._request_json(self._tencent_url, params=params)
        try:
            total = int(first["data"]["total"])
            items = list(first["data"]["rank_list"])
        except (KeyError, TypeError, ValueError) as exc:
            raise RuntimeError("腾讯全市场行情返回格式异常") from exc

        offsets = range(200, total, 200)

        def fetch_page(offset: int) -> list[dict]:
            page_params = {**params, "offset": str(offset)}
            payload = self._request_json(self._tencent_url, params=page_params)
            return list(payload["data"]["rank_list"])

        # Bounded concurrency keeps a complete scan fast without turning this
        # research tool into a high-frequency crawler.
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(fetch_page, offset) for offset in offsets]
            for future in as_completed(futures):
                items.extend(future.result())

        return {str(item["code"])[-6:]: item for item in items if item.get("code")}

    def _fetch_sina_rows(self) -> dict[str, dict]:
        count_response = requests.get(self._sina_count_url, headers=self._headers, timeout=15)
        count_response.raise_for_status()
        count_match = re.search(r"\d+", count_response.text)
        if not count_match:
            raise RuntimeError("新浪全市场股票数量返回格式异常")
        page_count = math.ceil(int(count_match.group()) / 100)

        def fetch_page(page: int) -> list[dict]:
            params = {
                "page": str(page),
                "num": "100",
                "sort": "symbol",
                "asc": "1",
                "node": "hs_a",
                "symbol": "",
                "_s_r_a": "page",
            }
            payload = self._request_json(self._sina_url, params=params)
            if not isinstance(payload, list):
                raise RuntimeError("新浪全市场行情返回格式异常")
            return payload

        items: list[dict] = []
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(fetch_page, page) for page in range(1, page_count + 1)]
            for future in as_completed(futures):
                items.extend(future.result())
        return {str(item["code"]).zfill(6): item for item in items if item.get("code")}

    def fetch(self, captured_at: datetime) -> list[MarketSnapshot]:
        market_change = _tencent_index_change()
        tencent_rows = self._fetch_tencent_rows()
        sina_rows = self._fetch_sina_rows()
        rows: list[MarketSnapshot] = []

        for code, tencent in tencent_rows.items():
            sina = sina_rows.get(code)
            if not sina:
                continue
            name = str(tencent.get("name") or sina.get("name") or "")
            price = _number(sina.get("trade"))
            day_low = _number(sina.get("low"))
            pct_change = _number(tencent.get("zdf"))
            turnover_rate = _number(tencent.get("hsl"))
            volume_ratio = _number(tencent.get("lb"))
            if (
                not code.startswith(("0", "3", "6"))
                or price <= 0
                or day_low <= 0
                or name.startswith(("ST", "*ST"))
            ):
                continue
            rows.append(MarketSnapshot(
                code=code,
                name=name,
                price=price,
                pct_change=pct_change,
                day_low=day_low,
                turnover_rate=turnover_rate,
                volume_ratio=volume_ratio,
                market_pct_change=market_change,
                captured_at=captured_at,
            ))
        if len(rows) < 3000:
            raise RuntimeError(f"腾讯/新浪快照交集异常，仅得到 {len(rows)} 只股票")
        return rows


class LiveSpotProvider:
    """Use a primary provider first and expose which provider actually won."""

    source_name = "unresolved"

    def fetch(self, captured_at: datetime) -> list[MarketSnapshot]:
        errors: list[str] = []
        for provider in (AkshareSpotProvider(), TencentSinaSpotProvider()):
            try:
                rows = provider.fetch(captured_at)
                self.source_name = provider.source_name
                return rows
            except Exception as exc:  # fallback behavior is verified at endpoint level
                errors.append(f"{provider.source_name}: {exc}")
        raise RuntimeError("所有实时行情源均不可用；" + " | ".join(errors))


class SampleProvider:
    """Repeatable research fixture, never mixed with real-time market output."""

    source_name = "内置研究样例"

    def fetch(self, captured_at: datetime) -> list[MarketSnapshot]:
        rows = [
            ("002833", "弘亚数控", 16.22, -4.1, 15.88, 3.4, 1.8),
            ("003010", "若羽臣", 28.65, -3.4, 28.08, 4.1, 1.4),
            ("603617", "君禾股份", 8.72, -5.3, 8.48, 2.8, 1.4),
            ("000859", "国风新材", 5.17, -6.8, 5.10, 10.2, 2.7),
            ("600872", "中炬高新", 21.30, -1.4, 21.05, 1.1, 0.6),
        ]
        return [MarketSnapshot(
            code=code,
            name=name,
            price=price,
            pct_change=pct,
            day_low=low,
            turnover_rate=turnover,
            volume_ratio=volume,
            market_pct_change=-5.0,
            captured_at=captured_at,
        ) for code, name, price, pct, low, turnover, volume in rows]
