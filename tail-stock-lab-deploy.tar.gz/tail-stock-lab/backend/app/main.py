from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.backtest import summarize_backtest
from app.data_provider import LiveSpotProvider, SampleProvider
from app.models import NextDayPath
from app.repository import StrategyRepository
from app.service import StrategyService
from app.strategies.fishing_v1 import FishingV1Strategy
from app.t1_collector import T1OutcomeCollector

strategy = FishingV1Strategy()
repository = StrategyRepository()
service = StrategyService(strategy, repository)

app = FastAPI(title="tail-stock-lab", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["*"], allow_headers=["*"])


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "strategy": strategy.strategy_id, "version": strategy.version}


@app.get("/api/strategies")
def list_strategies() -> dict:
    return {"strategies": [strategy.definition()]}


@app.get("/api/strategies/{strategy_id}/latest")
def latest(strategy_id: str):
    if strategy_id != strategy.strategy_id:
        raise HTTPException(status_code=404, detail="策略不存在")
    return repository.latest_run(strategy_id)


@app.post("/api/strategies/{strategy_id}/run")
def run_strategy(strategy_id: str, mode: str = Query("sample", pattern="^(sample|live)$")):
    if strategy_id != strategy.strategy_id:
        raise HTTPException(status_code=404, detail="策略不存在")
    try:
        return service.run(SampleProvider() if mode == "sample" else LiveSpotProvider(), mode=mode)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"策略运行失败：{exc}") from exc


@app.post("/api/strategies/{strategy_id}/backtest/sample")
def sample_backtest(strategy_id: str):
    """仅用于展示回测口径；真实历史回测必须由已存档的尾盘快照驱动。"""
    if strategy_id != strategy.strategy_id:
        raise HTTPException(status_code=404, detail="策略不存在")
    run = service.run(SampleProvider(), mode="sample")
    paths = [
        NextDayPath(code="002833", entry_price=16.22, prices=[16.26, 16.43, 16.37, 16.31], observed_at=run.observed_at),
        NextDayPath(code="003010", entry_price=28.65, prices=[28.59, 28.72, 28.96, 28.74], observed_at=run.observed_at),
        NextDayPath(code="603617", entry_price=8.72, prices=[8.66, 8.51, 8.43, 8.47], observed_at=run.observed_at),
    ]
    return summarize_backtest(run.signals, paths, mode="sample")


@app.post("/api/backtests/t1/collect")
def collect_t1_outcomes() -> dict:
    trades = T1OutcomeCollector(repository).collect_due()
    return {"collected": len(trades), "trades": trades}


@app.get("/api/backtests/t1/recent")
def recent_t1_outcomes() -> dict:
    trades = repository.recent_t1_outcomes()
    return {"trade_count": len(trades), "trades": trades}


web_dir = Path(__file__).resolve().parents[1] / "web"
if web_dir.is_dir():
    app.mount("/", StaticFiles(directory=web_dir, html=True), name="web")
