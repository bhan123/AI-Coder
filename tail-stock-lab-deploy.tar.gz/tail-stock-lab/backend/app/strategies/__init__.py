from .fishing_v1 import FishingV1Strategy

__all__ = ["FishingV1Strategy"]

