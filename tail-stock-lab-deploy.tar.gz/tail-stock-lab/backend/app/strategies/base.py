from __future__ import annotations

from abc import ABC, abstractmethod

from app.models import MarketSnapshot, Signal


class Strategy(ABC):
    strategy_id: str
    version: str
    name: str

    @abstractmethod
    def evaluate(self, snapshot: MarketSnapshot) -> Signal:
        """Score a timestamped observation without looking at future prices."""

    @abstractmethod
    def definition(self) -> dict:
        """Return the human-readable rule contract shown in the UI."""

