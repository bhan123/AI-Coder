from __future__ import annotations

from dataclasses import dataclass

from app.models import FactorContribution, MarketSnapshot, PriorityTag, Signal
from app.strategies.base import Strategy


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


@dataclass(frozen=True)
class FishingV1Config:
    min_decline_pct: float = -7.0
    max_decline_pct: float = -2.0
    min_rebound_pct: float = 0.7
    min_relative_strength: float = -0.3
    min_turnover_rate: float = 1.0
    min_volume_ratio: float = 0.8
    min_score: float = 62.0


class FishingV1Strategy(Strategy):
    """尾盘恐慌止跌候选器。

    这是筛选器而非预测器：所有因子都只来自 captured_at 的截面快照。
    """

    strategy_id = "fishing-reversal"
    version = "1.0.0"
    name = "尾盘恐慌止跌"

    def __init__(self, config: FishingV1Config | None = None) -> None:
        self.config = config or FishingV1Config()

    @staticmethod
    def _priority_tags(snapshot: MarketSnapshot, rebound_pct: float, relative_strength: float) -> list[PriorityTag]:
        """Map the user's preferred strategy hierarchy without inventing unseen inputs."""
        return [
            PriorityTag(
                key="sector_resonance_pullback",
                label="板块共振 + 尾盘回踩企稳",
                priority=1,
                status="partial",
                evidence=[
                    f"个股较日内低点回升 {rebound_pct:.2f}%",
                    f"相对上证强度 {relative_strength:.2f}%（指数当日 {snapshot.market_pct_change:.2f}%）",
                    "待验证：板块排名、同板块联动、尾盘均价线与缩量回踩",
                ],
            ),
            PriorityTag(
                key="trend_pullback",
                label="趋势股缩量回踩 + 尾盘站回均价线",
                priority=2,
                status="missing_data",
                evidence=["待接入：5/10/20 日均线、近 2–4 日量能、分时均价线与午后平台"],
            ),
            PriorityTag(
                key="breakout_confirmation",
                label="平台放量突破 + 尾盘确认",
                priority=3,
                status="missing_data",
                evidence=["待接入：20 日平台、近 5 日均量、突破后持续时间与上影线"],
            ),
            PriorityTag(
                key="leader_reconvergence",
                label="龙头分歧转一致",
                priority=4,
                status="missing_data",
                evidence=["待接入：板块龙头、涨停状态、封单变化与板块资金承接"],
            ),
            PriorityTag(
                key="tail_surge_only",
                label="单纯尾盘拉升",
                priority=5,
                status="excluded",
                evidence=["V1 不以尾盘直线拉升或竞价抢筹作为入选理由", "需分时逐笔数据后再识别并排除异常拉升"],
            ),
        ]

    def evaluate(self, snapshot: MarketSnapshot) -> Signal:
        rebound_pct = ((snapshot.price - snapshot.day_low) / snapshot.day_low * 100) if snapshot.day_low > 0 else 0.0
        relative_strength = snapshot.pct_change - snapshot.market_pct_change
        decline_score = _clip((abs(snapshot.pct_change) - 2.0) / 5.0 * 32.0, 0, 32)
        rebound_score = _clip(rebound_pct / 2.5 * 30.0, 0, 30)
        relative_score = _clip((relative_strength + 0.5) / 2.5 * 20.0, 0, 20)
        liquidity_score = _clip(snapshot.volume_ratio / 2.0 * 10.0, 0, 10)
        turnover_score = _clip(snapshot.turnover_rate / 5.0 * 8.0, 0, 8)
        score = round(decline_score + rebound_score + relative_score + liquidity_score + turnover_score, 1)

        gates = [
            self.config.min_decline_pct <= snapshot.pct_change <= self.config.max_decline_pct,
            rebound_pct >= self.config.min_rebound_pct,
            relative_strength >= self.config.min_relative_strength,
            snapshot.turnover_rate >= self.config.min_turnover_rate,
            snapshot.volume_ratio >= self.config.min_volume_ratio,
        ]
        eligible = all(gates) and score >= self.config.min_score
        risk_level = "high" if snapshot.pct_change <= -6.0 or snapshot.turnover_rate >= 15 else "medium" if snapshot.pct_change <= -4.5 else "low"
        reason = "满足尾盘恐慌止跌筛选条件" if eligible else "未满足 V1 的全部硬性筛选条件"
        return Signal(
            code=snapshot.code,
            name=snapshot.name,
            score=score,
            eligible=eligible,
            reason=reason,
            risk_level=risk_level,
            snapshot=snapshot,
            factors=[
                FactorContribution(key="decline", label="日内下跌", value=snapshot.pct_change, score=round(decline_score, 1), description="只接受 -7% 至 -2% 的受控恐慌下跌"),
                FactorContribution(key="rebound", label="低点回升", value=round(rebound_pct, 2), score=round(rebound_score, 1), description="收复日内低点，作为止跌确认"),
                FactorContribution(key="relative_strength", label="相对强度", value=round(relative_strength, 2), score=round(relative_score, 1), description="相对沪深市场的当日强弱"),
                FactorContribution(key="volume_ratio", label="量比", value=snapshot.volume_ratio, score=round(liquidity_score, 1), description="避免无量反抽"),
                FactorContribution(key="turnover", label="换手率", value=snapshot.turnover_rate, score=round(turnover_score, 1), description="要求基础流动性"),
            ],
            priority_tags=self._priority_tags(snapshot, rebound_pct, relative_strength),
        )

    def definition(self) -> dict:
        return {
            "id": self.strategy_id,
            "version": self.version,
            "name": self.name,
            "summary": "尾盘寻找受控下跌后从日内低点回升、相对市场更强的候选股。",
            "execution_window": "14:30–15:00",
            "risk_rule": "研究记录：策略假设使用 -3% 风险线，但隔夜跳空不能保证按该价格成交。",
            "factors": ["日内下跌", "低点回升", "相对强度", "量比", "换手率"],
        }
