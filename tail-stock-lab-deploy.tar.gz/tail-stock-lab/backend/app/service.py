from __future__ import annotations

from datetime import datetime, time
from uuid import uuid4
from zoneinfo import ZoneInfo

from app.data_provider import MarketDataProvider
from app.models import StrategyRun
from app.repository import StrategyRepository
from app.strategies.base import Strategy


class StrategyService:
    def __init__(self, strategy: Strategy, repository: StrategyRepository) -> None:
        self.strategy = strategy
        self.repository = repository

    @staticmethod
    def _is_tail_window(observed_at: datetime) -> bool:
        """A live signal is executable only in the declared Shanghai tail window."""
        local = observed_at.astimezone(ZoneInfo("Asia/Shanghai")) if observed_at.tzinfo else observed_at
        return local.weekday() < 5 and time(14, 30) <= local.time() <= time(15, 0)

    def run(self, provider: MarketDataProvider, *, mode: str, observed_at: datetime | None = None) -> StrategyRun:
        observed_at = observed_at or datetime.now(ZoneInfo("Asia/Shanghai"))
        snapshots = provider.fetch(observed_at)
        signals = [self.strategy.evaluate(snapshot) for snapshot in snapshots]
        execution_status = "sample" if mode == "sample" else (
            "tradable" if self._is_tail_window(observed_at) else "outside_tail_window"
        )
        eligible = [] if execution_status == "outside_tail_window" else sorted(
            (signal for signal in signals if signal.eligible), key=lambda item: item.score, reverse=True
        )[:3]
        run = StrategyRun(
            run_id=str(uuid4()), strategy_id=self.strategy.strategy_id, version=self.strategy.version,
            observed_at=observed_at, mode=mode, data_source=provider.source_name,
            execution_status=execution_status,
            universe_size=len(snapshots), signals=eligible,
        )
        self.repository.save_run(run, snapshots=snapshots)
        return run
