from __future__ import annotations

import sqlite3
from pathlib import Path

from app.models import MarketSnapshot, PaperTrade, Signal, StrategyRun


class StrategyRepository:
    def __init__(self, db_path: str = "data/tail_stock_lab.db") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS strategy_runs (
                    run_id TEXT PRIMARY KEY,
                    strategy_id TEXT NOT NULL,
                    version TEXT NOT NULL,
                    observed_at TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    capture_origin TEXT NOT NULL DEFAULT 'manual',
                    universe_size INTEGER NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS strategy_signals (
                    run_id TEXT NOT NULL,
                    rank INTEGER NOT NULL,
                    code TEXT NOT NULL,
                    name TEXT NOT NULL,
                    score REAL NOT NULL,
                    eligible INTEGER NOT NULL,
                    risk_level TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    PRIMARY KEY (run_id, code),
                    FOREIGN KEY (run_id) REFERENCES strategy_runs(run_id)
                );
                CREATE INDEX IF NOT EXISTS idx_strategy_runs_observed ON strategy_runs(strategy_id, observed_at DESC);
                CREATE TABLE IF NOT EXISTS market_snapshots (
                    run_id TEXT NOT NULL,
                    code TEXT NOT NULL,
                    name TEXT NOT NULL,
                    price REAL NOT NULL,
                    pct_change REAL NOT NULL,
                    day_low REAL NOT NULL,
                    turnover_rate REAL NOT NULL,
                    volume_ratio REAL NOT NULL,
                    market_pct_change REAL NOT NULL,
                    captured_at TEXT NOT NULL,
                    PRIMARY KEY (run_id, code),
                    FOREIGN KEY (run_id) REFERENCES strategy_runs(run_id)
                );
                CREATE INDEX IF NOT EXISTS idx_market_snapshots_captured ON market_snapshots(captured_at, code);
                CREATE TABLE IF NOT EXISTS t1_outcomes (
                    run_id TEXT NOT NULL,
                    code TEXT NOT NULL,
                    outcome_date TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    PRIMARY KEY (run_id, code),
                    FOREIGN KEY (run_id) REFERENCES strategy_runs(run_id)
                );
            """)
            existing_columns = {row[1] for row in conn.execute("PRAGMA table_info(strategy_runs)")}
            migrations = {
                "data_source": "TEXT NOT NULL DEFAULT 'unknown'",
                "execution_status": "TEXT NOT NULL DEFAULT 'sample'",
                "capture_origin": "TEXT NOT NULL DEFAULT 'manual'",
            }
            for column, definition in migrations.items():
                if column not in existing_columns:
                    conn.execute(f"ALTER TABLE strategy_runs ADD COLUMN {column} {definition}")
                    if column == "capture_origin":
                        conn.execute(
                            """UPDATE strategy_runs SET capture_origin = 'scheduled'
                               WHERE mode = 'live' AND execution_status = 'tradable'
                                 AND substr(observed_at, 12, 5) BETWEEN '14:48' AND '14:55'"""
                        )

    def save_run(self, run: StrategyRun, snapshots: list[MarketSnapshot] | None = None) -> None:
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO strategy_runs
                   (run_id, strategy_id, version, observed_at, mode, capture_origin, universe_size, created_at, data_source, execution_status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (run.run_id, run.strategy_id, run.version, run.observed_at.isoformat(), run.mode,
                 run.capture_origin, run.universe_size, run.observed_at.isoformat(), run.data_source, run.execution_status),
            )
            for rank, signal in enumerate(run.signals, 1):
                conn.execute(
                    "INSERT INTO strategy_signals VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (run.run_id, rank, signal.code, signal.name, signal.score, int(signal.eligible),
                     signal.risk_level, signal.model_dump_json()),
                )
            if snapshots:
                conn.executemany(
                    """INSERT INTO market_snapshots
                       (run_id, code, name, price, pct_change, day_low, turnover_rate, volume_ratio, market_pct_change, captured_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    [
                        (
                            run.run_id, snapshot.code, snapshot.name, snapshot.price,
                            snapshot.pct_change, snapshot.day_low, snapshot.turnover_rate,
                            snapshot.volume_ratio, snapshot.market_pct_change,
                            snapshot.captured_at.isoformat(),
                        )
                        for snapshot in snapshots
                    ],
                )

    def latest_run(self, strategy_id: str) -> StrategyRun | None:
        return self._latest_run(strategy_id)

    def latest_live_run(self, strategy_id: str) -> StrategyRun | None:
        return self._latest_run(strategy_id, mode="live")

    def latest_scheduled_run(self, strategy_id: str) -> StrategyRun | None:
        return self._latest_run(strategy_id, mode="live", capture_origin="scheduled")

    def _latest_run(
        self,
        strategy_id: str,
        *,
        mode: str | None = None,
        capture_origin: str | None = None,
    ) -> StrategyRun | None:
        with self._connect() as conn:
            where = ["strategy_id = ?"]
            params: list[str] = [strategy_id]
            if mode is not None:
                where.append("mode = ?")
                params.append(mode)
            if capture_origin is not None:
                where.append("capture_origin = ?")
                params.append(capture_origin)
            row = conn.execute(
                f"SELECT * FROM strategy_runs WHERE {' AND '.join(where)} ORDER BY observed_at DESC LIMIT 1",
                params,
            ).fetchone()
            if row is None:
                return None
            signals = [
                Signal.model_validate_json(signal["payload_json"])
                for signal in conn.execute(
                    "SELECT payload_json FROM strategy_signals WHERE run_id = ? ORDER BY rank", (row["run_id"],)
                )
            ]
        return StrategyRun(
            run_id=row["run_id"], strategy_id=row["strategy_id"], version=row["version"],
            observed_at=row["observed_at"], mode=row["mode"], capture_origin=row["capture_origin"], data_source=row["data_source"],
            execution_status=row["execution_status"], universe_size=row["universe_size"], signals=signals,
        )

    def get_run(self, run_id: str) -> StrategyRun | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM strategy_runs WHERE run_id = ?", (run_id,)).fetchone()
            if row is None:
                return None
            signals = [
                Signal.model_validate_json(signal["payload_json"])
                for signal in conn.execute(
                    "SELECT payload_json FROM strategy_signals WHERE run_id = ? ORDER BY rank", (run_id,)
                )
            ]
        return StrategyRun(
            run_id=row["run_id"], strategy_id=row["strategy_id"], version=row["version"],
            observed_at=row["observed_at"], mode=row["mode"], capture_origin=row["capture_origin"], data_source=row["data_source"],
            execution_status=row["execution_status"], universe_size=row["universe_size"], signals=signals,
        )

    def list_runs(
        self,
        strategy_id: str,
        *,
        limit: int = 30,
        date_from: str | None = None,
        date_to: str | None = None,
        mode: str | None = "live",
        capture_origin: str | None = "scheduled",
    ) -> list[dict]:
        """按 observed_at 倒序列出历史 run 元数据 + 候选数。

        ``date_from`` / ``date_to`` 仅取日期部分（YYYY-MM-DD），与 ``observed_at`` 前缀比对。
        默认只列 live 模式，避免历史样本数据混入前端。
        """
        where = ["strategy_id = ?"]
        params: list = [strategy_id]
        if mode is not None:
            where.append("mode = ?")
            params.append(mode)
        if capture_origin is not None:
            where.append("capture_origin = ?")
            params.append(capture_origin)
        where.append("execution_status != ?")
        params.append("sample")
        if date_from:
            where.append("substr(observed_at, 1, 10) >= ?")
            params.append(date_from)
        if date_to:
            where.append("substr(observed_at, 1, 10) <= ?")
            params.append(date_to)
        sql = (
            "SELECT r.run_id, r.strategy_id, r.version, r.observed_at, r.mode, r.capture_origin, "
            "       r.universe_size, r.data_source, r.execution_status, "
            "       COUNT(s.code) AS signal_count "
            "FROM strategy_runs r LEFT JOIN strategy_signals s ON s.run_id = r.run_id "
            f"WHERE {' AND '.join(where)} "
            "GROUP BY r.run_id "
            "ORDER BY r.observed_at DESC LIMIT ?"
        )
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(row) for row in rows]

    def list_recent_runs_all_strategies(
        self,
        *,
        limit: int = 50,
        date_from: str | None = None,
        date_to: str | None = None,
        mode: str | None = "live",
        capture_origin: str | None = "scheduled",
    ) -> list[dict]:
        """跨策略列历史 run，用于前端"今日各策略汇总"。"""
        where = ["1=1"]
        params: list = []
        if mode is not None:
            where.append("r.mode = ?")
            params.append(mode)
        if capture_origin is not None:
            where.append("r.capture_origin = ?")
            params.append(capture_origin)
        where.append("r.execution_status != ?")
        params.append("sample")
        if date_from:
            where.append("substr(r.observed_at, 1, 10) >= ?")
            params.append(date_from)
        if date_to:
            where.append("substr(r.observed_at, 1, 10) <= ?")
            params.append(date_to)
        sql = (
            "SELECT r.run_id, r.strategy_id, r.version, r.observed_at, r.mode, r.capture_origin, "
            "       r.universe_size, r.data_source, r.execution_status, "
            "       COUNT(s.code) AS signal_count "
            "FROM strategy_runs r LEFT JOIN strategy_signals s ON s.run_id = r.run_id "
            f"WHERE {' AND '.join(where)} "
            "GROUP BY r.run_id "
            "ORDER BY r.observed_at DESC LIMIT ?"
        )
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(row) for row in rows]

    def snapshots_for_run(self, run_id: str) -> list[MarketSnapshot]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM market_snapshots WHERE run_id = ? ORDER BY code", (run_id,)
            ).fetchall()
        return [
            MarketSnapshot(
                code=row["code"], name=row["name"], price=row["price"],
                pct_change=row["pct_change"], day_low=row["day_low"],
                turnover_rate=row["turnover_rate"], volume_ratio=row["volume_ratio"],
                market_pct_change=row["market_pct_change"], captured_at=row["captured_at"],
            )
            for row in rows
        ]

    def pending_t1_signals(self, before_date: str) -> list[tuple[str, Signal]]:
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT s.run_id, s.payload_json
                   FROM strategy_runs r
                   JOIN strategy_signals s ON s.run_id = r.run_id
                   LEFT JOIN t1_outcomes o ON o.run_id = s.run_id AND o.code = s.code
                    WHERE r.execution_status = 'tradable'
                      AND r.capture_origin = 'scheduled'
                     AND substr(r.observed_at, 1, 10) < ?
                     AND o.run_id IS NULL
                   ORDER BY r.observed_at, s.rank""",
                (before_date,),
            ).fetchall()
        return [(row["run_id"], Signal.model_validate_json(row["payload_json"])) for row in rows]

    def save_t1_outcome(self, run_id: str, outcome_date: str, trade: PaperTrade) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO t1_outcomes (run_id, code, outcome_date, payload_json) VALUES (?, ?, ?, ?)",
                (run_id, trade.code, outcome_date, trade.model_dump_json()),
            )

    def recent_t1_outcomes(self, limit: int = 100) -> list[PaperTrade]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT payload_json FROM t1_outcomes ORDER BY outcome_date DESC LIMIT ?", (limit,)
            ).fetchall()
        return [PaperTrade.model_validate_json(row["payload_json"]) for row in rows]
