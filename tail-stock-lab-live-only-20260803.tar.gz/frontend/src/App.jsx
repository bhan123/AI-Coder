import { useEffect, useMemo, useState } from 'react'
import {
  loadLatestForStrategy,
  loadStrategy,
  loadStrategyConfig,
  runAllStrategies,
  runStrategy,
  saveStrategyConfig,
} from './api'

const riskLabel = { low: '低', medium: '中等', high: '较高' }
const tagStatusLabel = { partial: '部分符合', missing_data: '待验证', excluded: '非主策略', matched: '主策略命中' }

const STRATEGY_TABS = [
  { id: 'fishing-reversal', label: 'V1 尾盘恐慌止跌', priority: 'V1' },
  { id: 'p1-sector-resonance', label: 'P1 板块共振', priority: 'P1' },
  { id: 'p2-trend-pullback', label: 'P2 趋势缩量回踩', priority: 'P2' },
  { id: 'p3-platform-breakout', label: 'P3 平台放量突破', priority: 'P3' },
  { id: 'p4-leader-reconvergence', label: 'P4 龙头分歧转一致', priority: 'P4' },
]

const STATUS_FILTERS = [
  { id: 'all', label: '全部' },
  { id: 'matched', label: '命中' },
  { id: 'partial', label: '部分符合' },
  { id: 'missing_data', label: '待验证' },
  { id: 'excluded', label: '非主策略' },
]

function PrimaryTag({ tags = [] }) {
  const tag = tags.find((item) => item.key === 'sector_resonance_pullback')
  if (!tag) return <span className="tag-chip missing_data">新快照后生成</span>
  return <span className={`tag-chip ${tag.status}`}>{tagStatusLabel[tag.status]}</span>
}

function PriorityTags({ tags = [] }) {
  if (!tags.length) return <p className="muted tag-empty">这是旧快照；重新运行后会生成优先级标签。</p>
  return <div className="priority-tags">{tags.map((tag) => <div className="priority-tag" key={tag.key}>
    <div><strong>{tag.label}</strong><span className={`tag-chip ${tag.status}`}>{tagStatusLabel[tag.status] || tag.status}</span></div>
    <ul>{tag.evidence.map((item) => <li key={item}>{item}</li>)}</ul>
  </div>)}</div>
}

function ConfigDrawer({ strategy, onClose }) {
  const [config, setConfig] = useState(strategy?.config || {})
  const [pending, setPending] = useState({})
  const [savedAt, setSavedAt] = useState(null)
  const [saving, setSaving] = useState(false)

  if (!strategy) return null

  const apply = async () => {
    setSaving(true)
    try {
      const result = await saveStrategyConfig(strategy.id, pending)
      setConfig(result.config)
      setPending({})
      setSavedAt(new Date().toLocaleTimeString('zh-CN'))
    } catch (error) {
      alert(error.message)
    } finally {
      setSaving(false)
    }
  }

  return <div className="config-drawer">
    <div className="drawer-head">
      <h3>{strategy.name} · 调参</h3>
      <button onClick={onClose}>×</button>
    </div>
    <p className="muted">覆盖字段会立即生效，下次跑策略按新阈值判定。非法字段会被忽略。</p>
    <div className="config-grid">
      {Object.entries(config).map(([key, value]) => (
        <label key={key}>
          <span>{key}</span>
          <input
            value={pending[key] ?? value}
            type={typeof value === 'number' ? 'number' : 'text'}
            step="any"
            onChange={(e) => {
              const raw = e.target.value
              const next = typeof value === 'number' ? Number(raw) : raw
              setPending((prev) => ({ ...prev, [key]: Number.isNaN(next) ? raw : next }))
            }}
          />
        </label>
      ))}
    </div>
    <div className="drawer-foot">
      {savedAt && <span className="muted">已保存 {savedAt}</span>}
      <button onClick={apply} disabled={saving || Object.keys(pending).length === 0}>
        {saving ? '保存中…' : '应用覆盖'}
      </button>
    </div>
  </div>
}

function formatTime(value) {
  return value ? new Date(value).toLocaleString('zh-CN', { hour12: false }) : '尚未运行'
}

export default function App() {
  const [definitions, setDefinitions] = useState([])
  const [activeStrategy, setActiveStrategy] = useState('fishing-reversal')
  const [runs, setRuns] = useState({})
  const [selected, setSelected] = useState(null)
  const [status, setStatus] = useState('正在加载策略定义…')
  const [running, setRunning] = useState(false)
  const [statusFilter, setStatusFilter] = useState('all')
  const [showConfig, setShowConfig] = useState(null)

  useEffect(() => {
    Promise.all([
      loadStrategy(),
      Promise.all(STRATEGY_TABS.map((tab) => loadLatestForStrategy(tab.id).catch(() => null))),
    ])
      .then(([catalog, latestPerStrategy]) => {
        setDefinitions(catalog.strategies)
        const runMap = {}
        latestPerStrategy.forEach((run, index) => {
          const tab = STRATEGY_TABS[index]
          if (run) runMap[tab.id] = run
        })
        setRuns(runMap)
        setSelected(runMap[activeStrategy]?.signals?.[0] ?? null)
        setStatus('已读取最近一次实时快照')
      })
      .catch((error) => setStatus(error.message))
  }, [])

  const run = runs[activeStrategy] || null
  const definition = definitions.find((d) => d.id === activeStrategy) || null

  const filteredSignals = useMemo(() => {
    const list = run?.signals || []
    if (statusFilter === 'all') return list
    return list.filter((signal) => (signal.priority_tags || []).some((t) => t.status === statusFilter))
  }, [run, statusFilter])

  const stats = useMemo(() => ({
    candidates: run?.signals?.length ?? 0,
    universe: run?.universe_size ?? 0,
    observed: formatTime(run?.observed_at),
  }), [run])

  async function execute() {
    setRunning(true)
    try {
      const nextRun = await runStrategy(activeStrategy)
      setRuns((prev) => ({ ...prev, [activeStrategy]: nextRun }))
      setSelected(nextRun.signals?.[0] ?? null)
      setStatus('实时快照已运行；请先核验数据时点再研究。')
    } catch (error) {
      setStatus(error.message)
    } finally {
      setRunning(false)
    }
  }

  async function executeAll() {
    setRunning(true)
    try {
      const result = await runAllStrategies()
      const updated = { ...runs }
      Object.entries(result.runs || {}).forEach(([sid, run]) => {
        if (!run.error) updated[sid] = run
      })
      setRuns(updated)
      setSelected(updated[activeStrategy]?.signals?.[0] ?? null)
      setStatus('全部策略已基于同一份实时快照运行。')
    } catch (error) {
      setStatus(error.message)
    } finally {
      setRunning(false)
    }
  }

  async function openConfig() {
    try {
      const result = await loadStrategyConfig(activeStrategy)
      const def = definitions.find((d) => d.id === activeStrategy)
      setShowConfig({ id: activeStrategy, name: def?.name || activeStrategy, config: result.config })
    } catch (error) {
      setStatus(error.message)
    }
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand">尾盘策略实验室</div>
      <nav>
        {STRATEGY_TABS.map((tab) => (
          <a key={tab.id} href={`#${tab.id}`} className={activeStrategy === tab.id ? 'active' : ''}
             onClick={(e) => { e.preventDefault(); setActiveStrategy(tab.id); setSelected(runs[tab.id]?.signals?.[0] ?? null) }}>
            <span className="tab-priority">{tab.priority}</span>{tab.label}
          </a>
        ))}
        <a href="#backtest">T+1 回测</a>
      </nav>
      <div className="sidebar-note">仅研究，不构成投资建议</div>
    </aside>
    <main className="workspace">
      <header className="topbar">
        <span>研究快照</span>
        <strong>{stats.observed}</strong>
        <span className="dot" />
        <span>{run ? (run.execution_status === 'tradable' ? '实时数据 · 可执行时段' : '实时数据 · 非可执行时段') : '尚无实盘快照'}</span>
        <span className="source-tag">{run?.data_source ?? '等待数据源'}</span>
      </header>
      <section className="headline">
        <div>
          <h1>{definition?.name ?? '尾盘恐慌止跌'} <span>· {definition?.version ?? 'V1'}</span></h1>
          <p>{definition?.summary ?? '加载中'}</p>
        </div>
        <div className="actions">
          <button className="primary" disabled={running} onClick={execute}>运行实时快照</button>
          <button className="ghost" disabled={running} onClick={executeAll}>实时·全部策略</button>
          <button className="ghost" disabled={running} onClick={openConfig}>参数调优</button>
        </div>
      </section>
      <p className="risk-copy">风险提示：策略只生成可研究的候选，不能保证次日盈利；隔夜跳空可能使风险线失效。</p>
      <p className="status-line" role="status">{status}</p>

      <section className="summary-strip">
        <div><span>候选信号</span><strong>{stats.candidates}</strong></div>
        <div><span>扫描范围</span><strong>{stats.universe || '—'}</strong></div>
        <div><span>执行时段</span><strong>{definition?.execution_window ?? '14:30–15:00'}</strong></div>
      </section>

      <section className="strategy-grid">
        {STRATEGY_TABS.map((tab) => {
          const tabRun = runs[tab.id]
          return <button key={tab.id}
            className={`strategy-card ${activeStrategy === tab.id ? 'active' : ''}`}
            onClick={() => { setActiveStrategy(tab.id); setSelected(tabRun?.signals?.[0] ?? null) }}>
            <strong>{tab.priority}</strong>
            <span>{tab.label}</span>
            <em>{tabRun?.signals?.length ?? 0} 候选 · {tabRun?.universe_size ?? '—'} 扫描</em>
          </button>
        })}
      </section>

      <section className="content-grid">
        <div className="signal-area">
          <div className="section-heading">
            <h2>{definition?.name ?? '候选池'}</h2>
            <div className="status-filters">
              {STATUS_FILTERS.map((f) => (
                <button key={f.id} className={statusFilter === f.id ? 'active' : ''}
                  onClick={() => setStatusFilter(f.id)}>
                  {f.label}
                </button>
              ))}
            </div>
          </div>
          <div className="table-wrap"><table>
            <thead><tr><th>排名</th><th>股票</th><th>评分</th><th>优先级标签</th><th>关键因子</th><th>风险</th></tr></thead>
            <tbody>
              {filteredSignals.length ? filteredSignals.map((signal, index) => <tr key={signal.code} onClick={() => setSelected(signal)} className={selected?.code === signal.code ? 'selected-row' : ''}>
                <td>{index + 1}</td>
                <td><strong>{signal.code} {signal.name}</strong><small>{signal.reason}</small></td>
                <td className="score">{signal.score}</td>
                <td><PrimaryTag tags={signal.priority_tags} /></td>
                <td>{(signal.factors || []).slice(0, 2).map((f) => `${f.label} ${f.value}`).join(' / ')}</td>
                <td className={`risk ${signal.risk_level}`}>{riskLabel[signal.risk_level]}</td>
              </tr>) : <tr><td colSpan="6" className="empty">无符合当前筛选的候选。可切到“全部”看完整池，或调低阈值。</td></tr>}
            </tbody>
          </table></div>
        </div>
        <aside className="inspector">
          <h2>信号详情</h2>
          {selected ? <>
            <h3>{selected.code} {selected.name}</h3>
            <p className="muted">评分 {selected.score} · 风险 {riskLabel[selected.risk_level]}</p>
            <div className="factor-list">
              {(selected.factors || []).map((factor) => <div key={factor.key}>
                <span>{factor.label}<small>{factor.description}</small></span>
                <strong>{factor.value}<em> +{factor.score}</em></strong>
              </div>)}
            </div>
            <h4 className="tag-heading">优先级策略适配</h4>
            <PriorityTags tags={selected.priority_tags} />
            <p className="rule-note">{definition?.risk_rule}</p>
          </> : <p className="muted">选择一条候选信号查看因子拆解。</p>}
        </aside>
      </section>

      <section id="backtest" className="backtest-band">
        <div className="section-heading">
          <div><h2>T+1 是否可盈利离场</h2><span>仅以已归档的实时尾盘信号和次日实际分钟路径统计</span></div>
        </div>
        <p className="muted">真实回测需要积累带时间戳的尾盘快照与次日分钟路径；不再展示内置样例数据。</p>
      </section>
    </main>
    {showConfig && <div className="drawer-overlay" onClick={() => setShowConfig(null)}>
      <div onClick={(e) => e.stopPropagation()}>
        <ConfigDrawer strategy={showConfig} onClose={() => setShowConfig(null)} />
      </div>
    </div>}
  </div>
}
