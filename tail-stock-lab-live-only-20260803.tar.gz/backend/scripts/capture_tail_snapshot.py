"""Cron-friendly tail-session snapshot capture.

Run this script at 14:50 Asia/Shanghai on trading days.  It fails closed outside
the strategy's declared execution window, so a late manual run cannot silently
produce a tradable signal from stale end-of-day data.
"""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.data_provider import (
    AkshareHistoryProvider,
    AkshareIntradayProvider,
    AkshareSectorProvider,
    LiveSpotProvider,
)
from app.repository import StrategyRepository
from app.service import StrategyService
from app.strategies.fishing_v1 import FishingV1Strategy
from app.strategies.sector_resonance_p1 import SectorResonancePullbackStrategy
from app.strategies.trend_pullback_p2 import TrendPullbackStrategy
from app.strategies.platform_breakout_p3 import PlatformBreakoutStrategy
from app.strategies.leader_reconvergence_p4 import LeaderReconvergenceStrategy


class _SnapshotProvider:
    def __init__(self, snapshots, source_name: str) -> None:
        self.snapshots = snapshots
        self.source_name = source_name

    def fetch(self, captured_at):
        return self.snapshots


class _EmptyHistoryProvider:
    source_name = "not required"

    def fetch(self, code, end, *, limit=30):
        return []


class _EmptyIntradayProvider:
    source_name = "not required"

    def fetch(self, code, captured_at):
        return []


class _EmptySectorProvider:
    source_name = "not required"

    def sector_for_code(self, code):
        return None

    def sectors(self):
        return []


def scheduled_strategies():
    return [
        FishingV1Strategy(),
        SectorResonancePullbackStrategy(),
        TrendPullbackStrategy(),
        PlatformBreakoutStrategy(),
        LeaderReconvergenceStrategy(),
    ]


def scheduled_service(strategy, repository, *, history, intraday, sectors) -> StrategyService:
    """Build the smallest live-data dependency set required by one strategy."""
    if strategy.strategy_id == FishingV1Strategy.strategy_id:
        return StrategyService(
            strategy,
            repository,
            history=_EmptyHistoryProvider(),
            intraday=_EmptyIntradayProvider(),
            sectors=_EmptySectorProvider(),
        )
    return StrategyService(
        strategy,
        repository,
        history=history if strategy.requires_history else _EmptyHistoryProvider(),
        intraday=intraday if strategy.requires_intraday else _EmptyIntradayProvider(),
        sectors=sectors if strategy.requires_sectors else _EmptySectorProvider(),
    )


def main() -> int:
    observed_at = datetime.now(ZoneInfo("Asia/Shanghai"))
    if not StrategyService._is_tail_window(observed_at):
        print("skip: only capture a tradable snapshot between 14:30 and 15:00 Asia/Shanghai")
        return 2

    live = LiveSpotProvider()
    snapshots = live.fetch(observed_at)
    provider = _SnapshotProvider(snapshots, live.source_name)
    repository = StrategyRepository()
    history = AkshareHistoryProvider()
    intraday = AkshareIntradayProvider()
    sectors = AkshareSectorProvider()

    for strategy in scheduled_strategies():
        service = scheduled_service(
            strategy,
            repository,
            history=history,
            intraday=intraday,
            sectors=sectors,
        )
        run = service.run(provider, mode="live", observed_at=observed_at)
        print(
            f"captured strategy={run.strategy_id} run={run.run_id} "
            f"source={run.data_source} universe={run.universe_size} "
            f"signals={len(run.signals)}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
