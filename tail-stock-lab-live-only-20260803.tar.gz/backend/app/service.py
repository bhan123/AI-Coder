from __future__ import annotations

from datetime import datetime, time
from typing import Iterable
from uuid import uuid4
from zoneinfo import ZoneInfo

from app.data_provider import (
    ContextAssembler,
    HistoryProvider,
    IntradayProvider,
    MarketDataProvider,
    SampleHistoryProvider,
    SampleIntradayProvider,
    SampleSectorProvider,
    SectorProvider,
)
from app.models import StrategyRun
from app.repository import StrategyRepository
from app.strategies.base import Strategy


class StrategyService:
    def __init__(
        self,
        strategy: Strategy,
        repository: StrategyRepository,
        *,
        history: HistoryProvider | None = None,
        intraday: IntradayProvider | None = None,
        sectors: SectorProvider | None = None,
    ) -> None:
        self.strategy = strategy
        self.repository = repository
        self.assembler = ContextAssembler(
            history or SampleHistoryProvider(),
            intraday or SampleIntradayProvider(),
            sectors or SampleSectorProvider(),
        )

    @staticmethod
    def _is_tail_window(observed_at: datetime) -> bool:
        """A live signal is executable only in the declared Shanghai tail window."""
        local = observed_at.astimezone(ZoneInfo("Asia/Shanghai")) if observed_at.tzinfo else observed_at
        return local.weekday() < 5 and time(14, 30) <= local.time() <= time(15, 0)

    def run(self, provider: MarketDataProvider, *, mode: str, observed_at: datetime | None = None) -> StrategyRun:
        observed_at = observed_at or datetime.now(ZoneInfo("Asia/Shanghai"))
        if mode == "sample":
            observed_at = observed_at.replace(hour=14, minute=50, second=0, microsecond=0)
        snapshots = provider.fetch(observed_at)
        contexts = self.assembler.assemble(
            snapshots,
            observed_at,
            history_required=self.strategy.requires_history,
            intraday_required=self.strategy.requires_intraday,
            sector_required=self.strategy.requires_sectors,
            enrich_predicate=self.strategy.should_enrich_context,
            enrich_limit=self.strategy.max_enrichment_candidates,
            enrich_priority=self.strategy.enrichment_priority,
        )
        signals = [self.strategy.evaluate_context(contexts[snap.code]) for snap in snapshots]
        execution_status = "sample" if mode == "sample" else (
            "tradable" if self._is_tail_window(observed_at) else "outside_tail_window"
        )
        eligible = [] if execution_status == "outside_tail_window" else sorted(
            (signal for signal in signals if signal.eligible), key=lambda item: item.score, reverse=True
        )[:3]
        run = StrategyRun(
            run_id=str(uuid4()), strategy_id=self.strategy.strategy_id, version=self.strategy.version,
            observed_at=observed_at, mode=mode, data_source=provider.source_name,
            execution_status=execution_status,
            universe_size=len(snapshots), signals=eligible,
        )
        self.repository.save_run(run, snapshots=snapshots)
        return run

    def preview(self, provider: MarketDataProvider, *, mode: str = "sample", limit: int = 5) -> dict:
        """不在尾盘窗口也允许跑一次，把所有 eligible + 前 N 个 ineligible 都返回，方便评估调参。"""
        observed_at = datetime.now(ZoneInfo("Asia/Shanghai"))
        if mode == "sample":
            observed_at = observed_at.replace(hour=14, minute=50, second=0, microsecond=0)
        snapshots = provider.fetch(observed_at)
        contexts = self.assembler.assemble(
            snapshots,
            observed_at,
            history_required=self.strategy.requires_history,
            intraday_required=self.strategy.requires_intraday,
            sector_required=self.strategy.requires_sectors,
            enrich_predicate=self.strategy.should_enrich_context,
            enrich_limit=self.strategy.max_enrichment_candidates,
            enrich_priority=self.strategy.enrichment_priority,
        )
        signals = [self.strategy.evaluate_context(contexts[snap.code]) for snap in snapshots]
        eligible = sorted(
            (s for s in signals if s.eligible), key=lambda item: item.score, reverse=True
        )[:limit]
        near_miss = sorted(
            (s for s in signals if not s.eligible), key=lambda item: item.score, reverse=True
        )[:limit]
        return {
            "strategy_id": self.strategy.strategy_id,
            "universe_size": len(snapshots),
            "eligible_count": sum(1 for s in signals if s.eligible),
            "eligible": [s.model_dump(mode="json") for s in eligible],
            "near_miss": [s.model_dump(mode="json") for s in near_miss],
        }

    def run_all_strategies(
        self,
        provider: MarketDataProvider,
        *,
        mode: str,
        observed_at: datetime | None = None,
        strategies: list[Strategy] | None = None,
    ) -> dict[str, StrategyRun]:
        """对一组策略分别跑同一份 context，结果用 strategy_id 做键返回。

        这就是 UI 上"P1 / P2 / P3 / P4 / V1 全部跑一遍"的来源——共用同一份行情快照、
        日线、分时和板块上下文，候选可以横向对比。
        """
        observed_at = observed_at or datetime.now(ZoneInfo("Asia/Shanghai"))
        if mode == "sample":
            observed_at = observed_at.replace(hour=14, minute=50, second=0, microsecond=0)
        snapshots = provider.fetch(observed_at)
        contexts = self.assembler.assemble(snapshots, observed_at)
        runs: dict[str, StrategyRun] = {}
        strategies = strategies or []
        for strategy in strategies:
            signals = [strategy.evaluate_context(contexts[snap.code]) for snap in snapshots]
            execution_status = "sample" if mode == "sample" else (
                "tradable" if self._is_tail_window(observed_at) else "outside_tail_window"
            )
            eligible = [] if execution_status == "outside_tail_window" else sorted(
                (signal for signal in signals if signal.eligible), key=lambda item: item.score, reverse=True
            )[:3]
            run = StrategyRun(
                run_id=str(uuid4()), strategy_id=strategy.strategy_id, version=strategy.version,
                observed_at=observed_at, mode=mode, data_source=provider.source_name,
                execution_status=execution_status,
                universe_size=len(snapshots), signals=eligible,
            )
            self.repository.save_run(run, snapshots=snapshots)
            runs[strategy.strategy_id] = run
        return runs
